<link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
<script type="text/javascript" src="include/dist/script/showToast.js"></script>

<?php
include_once("include/connection.php");


$lemail = $_POST['lemail'];
$lpassword1 = $_POST['lpassword'];
$lpassword = base64_encode($lpassword1);

if ($lemail != "" && $lpassword != "") {
    // sleep(2);
    $lq = "select * from user where email='$lemail' && password='$lpassword'";
    $ex = mysql_query($lq);
    $row = mysql_num_rows($ex);
    $fet = mysql_fetch_array($ex);

    if ($row == 1) {

        if ($fet['status'] == "1" && $fet['verification_status'] == "1") {

            $_SESSION['u_id'] = $fet['u_id'];
            //$_SESSION['email']=$fet['email'];
            $_SESSION['name'] = $fet['name'];
            $_SESSION['as'] = $fet['user_type'];

            if($fet['user_type']==1)
            {
             ?>
            <script>location.href = 'home_agent.php';</script>
            <?php
            }
            else
            {
              ?>
            <script>location.href = 'home_customer.php';</script>
            <?php
            }
          
        } else if ($fet['status'] == "0") {
            ?>
            <script>showToastred.show('your Account deactived by admin', 4000)</script>
            <?php
        } else {
            ?>
            <script>showToastred.show('Invalid email or password', 4000)</script>
            <?php
        }
    } else {
        ?>
        <script>showToastred.show('Invalid email or password', 4000)</script>
        <?php
    }
}
?>


