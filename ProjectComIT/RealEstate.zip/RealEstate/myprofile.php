 <?php include("include/connection.php");?>

<?php
if(!isset($_SESSION['u_id']))
{
header("location:index.php");
}
?>

<?php
    $e=$_SESSION['u_id'];
    $lq="select * from user where u_id='$e'";
				$ex=mysql_query($lq);
				$fet=mysql_fetch_array($ex);
   ?>






 <!DOCTYPE HTML>
 <html class="no-js">
 <head>
<!-- Basic Page Needs
  ================================================== -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Real Estate</title>
  <link rel="icon" type="image/png" href="favicon.png">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="format-detection" content="telephone=no">
<!-- CSS
  ================================================== -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
  <!-- Color Style -->
  <link class="alt" href="colors/color1.css" rel="stylesheet" type="text/css">
  <link href="style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
<!-- SCRIPTS
  ================================================== -->
  <script src="js/modernizr.js"></script><!-- Modernizr -->
  
</head>
<body class="home">

  <div class="body">
    <!-- Start Site Header -->
    <!-- Start Site Header -->
    <header class="site-header">

      <?php include("top_header.php");?>
      
      <?Php include("middle_header.php");?>

      <?php include("menu.php");?>
         
    </header>

    <?php
    
    ?>
    
    <!-- Start Content -->
    <div class="main" role="main" >
      <div id="content" class="content full">
        <div class="featured-blocks">
          <div class="container">
              <!---maincontant contant                                                             ------->

</style>


<div class="container">

  <!-- Modal -->
  <div  role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Profile</h4>
        </div>
        <div class="modal-body">
    <!-------- login--------------------->
    <div class="container">
<br />
  <form class="form-horizontal" role="form" method="post" name="reg">
      <div id="ed"> </div>

<div class="form-group">
      <label class="control-label col-sm-2">Email:</label>
      <div class="col-sm-3">          
          <input type="text"  class="form-control"  value="<?php echo $fet['email'];?>"  readonly>
      </div>
    </div>
  


   <div class="form-group">
      <label class="control-label col-sm-2">Name:</label>
      <div class="col-sm-3">          
          <input type="text" id="rname" class="form-control"  placeholder="Enter Name" value="<?php echo $fet['name'];?>"  onkeypress="return RestrictSpace()">
      </div>
    </div>
  

  <div class="form-group">
      <label class="control-label col-sm-2">Mobil no:</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" id="rmobil" placeholder="Enter Mobil no" value="<?php echo $fet['mobile'];?>" onkeypress="return isNumberKey(event)" maxlength="10">
      </div>
    </div>

      <div class="form-group">
      <label class="control-label col-sm-2"></span> </label>
      <div class="col-sm-3">          
          
           <input type="button" id="edit" name="edit" class="btn btn-warning" style="width: 100%;" value="edit"/>
        
      </div>
    </div>
  </form>
</div>
    
<!---------------------------end------------>

</div>

</div>

</div>
</div>

</div>




                <!---end                                                                      contant------->
          </div>
        </div>
       


         <div class="padding-tb45 bottom-blocks">
          <div class="container">

          </div>
        </div>

        
       <!-- End Site Footer -->
       <a id="back-to-top"><i class="fa fa-angle-double-up"></i></a>
     </div>
      </div>
          <footer class="site-footer-bottom">
         <?Php include("footer.php");?>
       </footer>
     <script src="js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call --> 
     <script src="plugins/flexslider/js/jquery.flexslider.js"></script> <!-- FlexSlider --> 
     <script src="js/helper-plugins.js"></script> <!-- Plugins --> 
     <script src="js/bootstrap.js"></script> <!-- UI --> 
     <script src="js/waypoints.js"></script> <!-- Waypoints --> 
     <script src="js/init.js"></script> <!-- All Scripts -->
     <!--[if lte IE 9]><script src="js/script_ie.js"></script><![endif]--> 


   </body>

   </html>
   
<script type="text/javascript">
function RestrictSpace() {
    if (event.keyCode == 32) {
        return false;
    }
}

function isNumberKey(evt){
          var charCode = (evt.which) ? evt.which : event.keyCode;
          if ((charCode < 48 || charCode > 57))
             return false;

          return true;
       }

$(function() {$("#edit").click(function() {

var username = /^[0-9a-zA-Z]+$/;  
var rname = $("#rname").val();
var rmobil = $("#rmobil").val();


if(rname==''){
//alert("Enter name");
 showToastblack.show('Enter User Name!',2000)
 $("#rname").focus();
}

else if($("#rname").val().search(username) == -1) {
         // alert("user name must be number and alphabetes"); 
       showToastblack.show('user name must be number and alphabetes',2000)   
       $("#rname").focus();
 }
 
 else if(rmobil==""){
  //alert("enter mobil number");
  showToastblack.show('enter mobil number',2000)
  $("#rmobil").focus();
  }
  
else if(isNaN(rmobil)){
  showToastblack.show('Enter the valid Mobile Number(Like : 9566137117)',2000)
  $("#rmobil").focus();
//alert("Enter the valid Mobile Number(Like : 9566137117)");
}

  
else if(rmobil.length<10 || rmobil.length>10 ){
//alert("enter mobil must be 10 digit");
showToastblack.show('enter mobil must be 10 digit',2000)
$("#rmobil").focus();
    }
    
else
{
 document.getElementById("edit").value="Editing......";
var dataString = 'rname='+ rname +'&rmobil='+ rmobil;
$.ajax({
type: "POST",
url: "request_editprofile.php",
data: dataString,
cache: true,
success: function(html)
{

$("#ed").after(html);
 document.getElementById("edit").value="Edit";
 showToastblack.show('sucessfully updated your profile ',2000)
//document.getElementById('rname').value='';
//document.getElementById('rmobil').value='';

//$("#rname").val()='';
//$("#email").focus();
}  
});
}
return false;
});
});

</script>
