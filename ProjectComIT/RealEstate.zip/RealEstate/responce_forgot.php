 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  
 <?php include_once("include/connection.php");

 
 $femail=$_POST['femail'];
                if($femail!="")
                        {
                   // sleep(2);
                            $forgot="select * from user where email='$femail'";
				$ex=mysql_query($forgot);
				$row=mysql_num_rows($ex);
				$fet=mysql_fetch_array($ex); 
                                
                                    if($row==1)
					 {
                                        
                                        $data =$fet['password'];
                                        $password= base64_decode($data);
					$to=$femail;
					$subject="forgot password";							
					$header="from: propertys <darshantank2012@gmail.com>";					
					$message.="your password is  ".$password;
					$sentmail = mail($to,$subject,$message,$header);
					            if($sentmail)
							 {
							 ?>
                                                          <script>showToastblack.show('password sent to your email.',2000) </script>
					  		<?php
							 }
							 else
							 { 
							  ?>
                                                           <script>showToastblack.show('Unable to send mail.',2000) </script>                    					
					  		<?php
							 }

			                 }
				    else
				     {
				?>
                                   <script>showToastblack.show('email address not found or registered',2000) </script>  
                     		
				 <?php
 
				     }
			
                        }                    
 ?>


