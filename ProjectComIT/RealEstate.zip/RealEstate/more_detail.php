 <?php include("include/connection.php");?>
<?php
session_destroy();
?>
 <!DOCTYPE HTML>
 <html class="no-js">
 <head>
<!-- Basic Page Needs
  ================================================== -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Real Estate</title>
  <link rel="icon" type="image/png" href="favicon.png">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="format-detection" content="telephone=no">
<!-- CSS
  ================================================== -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
  <!-- Color Style -->
  <link class="alt" href="colors/color1.css" rel="stylesheet" type="text/css">
  <link href="style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
<!-- SCRIPTS
  ================================================== -->
  <script src="js/modernizr.js"></script><!-- Modernizr -->
  
</head>
<body class="home">

  <div class="body">
    <!-- Start Site Header -->
    <!-- Start Site Header -->
    <header class="site-header">

      <?php include("top_header.php");?>
      
      <?Php include("middle_header.php");?>

      <?php include("menu.php");?>
         <?php include_once("include/signup.php");?>
        <?Php include_once("include/login.php"); ?>
        <?Php include_once("include/forgotpass.php"); ?>
        
        
        
        
    </header>
    <!-- End Site Header -->
    <!-- End Site Header -->
    <!-- Site Showcase -->

    <!-- End Hero Slider --> 
    <!-- Site Search Module -->
    

</div>
    
   <!--- end search ----------------->
   
   
    <!-- Start Content -->
    <div class="main" role="main">
      <div id="content" class="content full">
        <div class="featured-blocks">
            <div class="container" >
                

              <!------- ----------------------------------------------table---------------------------------------->
              <?php
              $p=$_REQUEST['p'];
              $u=$_REQUEST['u'];
              
               $q = mysql_query("select properties.*,cities.city_name,states.state_name,countries.country_name,Category_type from properties 
                join cities on properties.city = cities.city_id 
                  join states on cities.state_id = states.state_id 
                 join countries on  states.country_id  = countries.country_id
                join category on  properties.Category_id = category.Category_id where p_id=$p");
               //$q = mysql_query("SELECT * FROM `properties`");
			while($arr=mysql_fetch_object($q))
			{
                            $a++;
			?>
                  
                   <tr >
         
         <td colspan="0"> <div style="font-size: 15pt;color: #0052cc;" ><?php echo $arr->address; ?></div></td>
     </tr>
                <div class="col-sm-4" align="center">  
                    <br>
                    
                    <?Php 
                    if($arr->pro_image=="")
                    {
                     ?>
                    <img src="images/images.png" width="200" height="100" draggable="false"/> 
                     <?php
                    }
                    else 
                        {?>
                     <img src="<?php echo $arr->pro_image; ?>" width="400" height="170" draggable="false"/> 
     
                    <?php
                        }
                     ?>
                    </div>

                 
   <td width="62%" align="left" >
         
      <br>
      <div style="font-size:15pt;">
                      <i class="fa fa-inr" aria-hidden="true"></i>  <?php echo $arr->price." - ".$arr->Bedrooms."BHK ,".$arr->city_name; ?><br><br>
                   
                 

                      <i class="fa fa-star" aria-hidden="true"></i> <?php echo $arr->action; ?><br><br>

                        <i class="fa fa-area-chart" aria-hidden="true"></i> <?php echo $arr->area." sqft"; ?><br><br>
                    <i class="fa fa-globe" aria-hidden="true"></i> <?php echo $arr->country_name.", ".$arr->state_name; ?><br><br>
                    <i class="fa fa-phone" aria-hidden="true"></i> <?php echo $arr->mobile; ?><br><br>

                        <div style="text-align: right;"><a href="review_display_login.php?p=<?php echo $arr->p_id; ?>"  target="_blank" class="btn btn-info btn-sm"><i class="fa fa-th-large"></i> view reviews </a></div>
                      </div> 
               
  </td>
  <br>
                  <hr style="background-color:#999966;">
                        <?Php
                        }
                   ?>
             
                 
                  <div style="font-size: larger;">more images<div>
              
                          <br>
                          
                          <?php
                          
               static $a=1;
               $qq = mysql_query("SELECT * FROM `photo` WHERE p_id='$p'"); 
               ?>
            
                          <div class="container" style="text-align: center;">
                        <?php
                        $a++;
			while($a=mysql_fetch_object($qq))
			{
		         ?>
                              <img src="<?php echo $a->path;?>" class="img-rounded" alt="Cinque Terre" width="300" height="300" style="margin-top: 20px;margin-left: 10pt;">
                
                          <?php
                          }
                          ?>
           
                   </div>
             

              
              
              <!--------------------------------------------------end table ---------------------------------------->
              
              
              
              
              
          </div>
        </div>
    
     



       
       <!-- End Site Footer -->
       <a id="back-to-top"><i class="fa fa-angle-double-up"></i></a>
     </div>
      </div>
         <footer class="site-footer-bottom">
         <?Php include("footer.php");?>
       </footer>
     <script src="js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call --> 
     <script src="plugins/flexslider/js/jquery.flexslider.js"></script> <!-- FlexSlider --> 
     <script src="js/helper-plugins.js"></script> <!-- Plugins --> 
     <script src="js/bootstrap.js"></script> <!-- UI --> 
     <script src="js/waypoints.js"></script> <!-- Waypoints --> 
     <script src="js/init.js"></script> <!-- All Scripts -->
     <!--[if lte IE 9]><script src="js/script_ie.js"></script><![endif]--> 


   </body>

   </html>
    <script>

  




<?php include_once("include/validation.php");?>
