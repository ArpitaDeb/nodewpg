 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  
 <?php include_once("include/connection.php");
 
  $uid=$_SESSION['u_id'];    
 $categoty=$_POST['categoty'];
 $area=$_POST['area'];
  $price=$_POST['price'];
 $bedrooms=$_POST['bedrooms'];
  $address=$_POST['address'];

  $fcity=$_POST['fcity'];
 $mobile=$_POST['mobile'];
 $action=$_POST['action'];

 if($categoty!="")
 {                    
     
                        
  $q = mysql_query("insert into request(u_id,Category_id,area,price,Bedrooms,action,des,city,mobile)"
       . " values($uid,$categoty,$area,$price,$bedrooms,'$action','$address',$fcity,$mobile)");
  
  
             
                        if($q)
                        {
                             ?>
                             <script>showToastblack.show('sucessfully add propertys Request.',4000) </script>
                           <?php
                        }
                        else
                        {
                        ?>
                             <script>showToastblack.show('not added',4000) </script>
                           <?php
                        }


     
 }
  
 ?>

  






