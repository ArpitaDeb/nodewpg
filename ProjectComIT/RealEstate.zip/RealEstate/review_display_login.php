 <?php include("include/connection.php");?>


<!DOCTYPE HTML>
<html class="no-js">
<head>
<!-- Basic Page Needs
  ================================================== -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Real Estate</title>
  <link rel="icon" type="image/png" href="favicon.png">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="format-detection" content="telephone=no">
<!-- CSS
  ================================================== -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
  <!-- Color Style -->
  <link class="alt" href="colors/color1.css" rel="stylesheet" type="text/css">
  <link href="style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
<!-- SCRIPTS
  ================================================== -->
  <script src="js/modernizr.js"></script><!-- Modernizr -->
  
</head>
<body class="home">

  <div class="body">
    <!-- Start Site Header -->
    <!-- Start Site Header -->
    <header class="site-header">

      <?php include("top_header.php");?>
      
      <?Php include("middle_header.php");?>

      <?php include("menu.php");?>
       <?php include_once("include/signup.php");?>
        <?Php include_once("include/login.php"); ?>
        <?Php include_once("include/forgotpass.php"); ?>

      </header>

      <div class="main" role="main">
      <div id="content" class="content full">
        <div class="featured-blocks">
            <div class="container" >
            <?php
             $a=0;

           $p=$_REQUEST['p'];
             // $u=$_REQUEST['u'];
              // $u=$_SESSION['u_id'];

?>

                

              <!------- ----------------------------------------------table---------------------------------------->
       <?php
                 
     // $q = mysql_query("SELECT * FROM `rating` WHERE   property_id='$p' ");
       $q = mysql_query("SELECT rating.*,user.name FROM `rating` join user on user.u_id = rating.u_id  WHERE   property_id='$p' ");
    
              
      while($arr=mysql_fetch_array($q))
      {
         $a++;
      ?>
                  
      <tr>
    
         
         <td colspan="0"> 

              <div class="col-sm-4" align="center">  
                    <br>
                   
                    <?php 

                        if($arr['rating']==1)
                        {
                          ?>
                      
                       <img src="images/1.png" width="100pt" > <br>
                       
                        <?php
                          }

                        else if ($arr['rating']==2) 
                        {
                         ?>
 <img src="images/2.png" width="100pt" > <br>
  
                         <?php
                        }


                         else if ($arr['rating']==3) 
                        {
                         ?>
 <img src="images/3.png" width="100pt" > </br>
  
                         <?php
                        }

                        else
                        {

                        }
                        ?>
                        
                    </div>


         </td>
     </tr>
                

                 
   <td width="62%" align="left">
         <br>
         <br>
      <br>
                      <?php echo '<b style="color: #423939;font-size: 14pt;">'."Review By ".$arr['name'].'</b>'.": ".$arr['message']; ?>
  
                
              
  </td>
  <br>
                  <hr style="background-color:#999966;">
                        <?Php
                        }
                   ?>
             

                  
             

<?php
if($a==0)
{
 echo '<b style="color: #423939;font-size: 11pt;text-align: center;">'."no record found related ".'</b>';
}
?>

              
              
              <!--------------------------------------------------end table ---------------------------------------->
              
              
              
              
              
          </div>
        </div>
    
         


         <div class="padding-tb45 bottom-blocks">
          <div class="container">


          </div>
        </div>

        
        <!-- End Site Footer -->
        <a id="back-to-top"><i class="fa fa-angle-double-up"></i></a>
      </div>
    </div>

    <script src="js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call --> 
    <script src="plugins/flexslider/js/jquery.flexslider.js"></script> <!-- FlexSlider --> 
    <script src="js/helper-plugins.js"></script> <!-- Plugins --> 
    <script src="js/bootstrap.js"></script> <!-- UI --> 
    <script src="js/waypoints.js"></script> <!-- Waypoints --> 
    <script src="js/init.js"></script> <!-- All Scripts -->
    <!--[if lte IE 9]><script src="js/script_ie.js"></script><![endif]--> 


  </body>

  </html>
  <script>

   <?php include_once("include/validation.php");?>