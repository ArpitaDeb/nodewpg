<?php 
include("../include/connection.php");
?>
<?php
if(!isset($_SESSION['id']))
{
header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
   
    <title>Admin | </title>
 <link rel="stylesheet" type="text/css" href="dist/style/showToast.css" / >
 <script type="text/javascript" src="dist/script/showToast.js"></script>
    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
    

  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
             <a href="index.html" class="site_title"><span>Welcome <?php echo $_SESSION['name']?></span></a>
            </div>

          
            <br />

            <!-- sidebar menu -->
           <?php include"menu.php" ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">



              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>User Detail</h3>
              </div>           
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                 

 <div class="container">
 
     <form role="form" method="post">
    <div class="col-sm-3">
<br>
      <select class="form-control" id="l" name="l">
    <option value="">Select for search</option>
    <option value="name">search by name</option>
    <option value="email">search by email</option>
       <option value="type">search by type</option>
  </select>
      
    </div>

<div class="col-sm-3">
             <br>
             <input type="text" class="form-control" name="r" id="r" placeholder="Enter values"> 
     
      
    </div>

         <div class="col-sm-3">
             <br>
    <input type="button" name="search" value="search" onclick="se();" class="btn btn-info"/>
      
    </div>
   
  </form>
</div>



                   
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      
                      
                      
                      
                    <div id="txtHint"></div>
                    <div id="load" align="center"></div>
                      
                   
                      
                
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include 'footer.php'; ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    
    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
  </body>
</html>
    <script>

  function showtable()
  {

  if (window.XMLHttpRequest) 
   {
    xmlhttp=new XMLHttpRequest();
   }
   else
   
 { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() 
{ 
    if (xmlhttp.readyState==4 && xmlhttp.status==200) 
    {
      document.getElementById('load').innerHTML="";
      document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
	     
  }

 xmlhttp.open("POST","request_user_info.php",true);
 xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlhttp.send();
 document.getElementById('load').innerHTML="data loading....";

}

showtable()

function status(s1,s2)
 {
  var x;
  
  if (window.XMLHttpRequest) 
   {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
   else
   
 { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	
  }
  xmlhttp.onreadystatechange=function() 
{
  
    if (xmlhttp.readyState==4 && xmlhttp.status==200) 
   {

      hide();
     document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
     showtable()
    } 
    
  }  
   
	if (confirm("do you want to change status?!") == true) 
            {
	 
         show('status is changing..');
         xmlhttp.open("POST","request_user_info.php",true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
              xmlhttp.send("s1="+s1+"&s2="+s2);
             $(document).ready(function () {$("#dd :input").attr("disabled", true); });
   
          }
}


function del(d)
 {
  var d;
  
  if (window.XMLHttpRequest) 
   {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
   else
   
 { 
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	
  }
  xmlhttp.onreadystatechange=function() 
{
  
    if (xmlhttp.readyState==4 && xmlhttp.status==200) 
   {
  
	    hide();
     document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
	    showtable()
		
    }
	     
  }
  
  if (confirm("do you want to delete record...?") == true) 
	{
	 
  show('data deleting......');
  xmlhttp.open("POST","request_user_info.php",true);
  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlhttp.send("d="+d);
    $(document).ready(function () {$("#dd :input").attr("disabled", true); });
  
     }
}
 


function se()
 {
   var l = document.getElementById("l").value;
   var r = document.getElementById("r").value;

   if(l=="")
   {
alert("select field");
   }
   else if (r=="")
    {
alert("Enter values");
    }

   else
   {
     if (window.XMLHttpRequest) 
   {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
   else
   
 { 
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  
  }
  xmlhttp.onreadystatechange=function() 
{
  
    if (xmlhttp.readyState==4 && xmlhttp.status==200) 
   {
  
      hide();
     document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
      //showtable()
    
    }
       
  }
  
 
  show('data searching......');
  xmlhttp.open("POST","request_user_info.php",true);
  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   xmlhttp.send("l="+l+"&r="+r);
    $(document).ready(function () {$("#dd :input").attr("disabled", true); });
  
    
   }
  
  
 
}
</script>