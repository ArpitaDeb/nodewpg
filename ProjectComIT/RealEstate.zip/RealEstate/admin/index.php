<?php 
include("../include/connection.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Gentelella Alela! | </title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
  
    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body >
    <div>
<!----------------login-------------------->

<?php 
	if(isset($_POST['login']))
	{
	$email=$_POST['email'];
	$pss=$_POST['pass'];
	 $qs="select * from admin where email='$email' && password='$pss'";
	$ex=mysql_query($qs);
	$row=mysql_num_rows($ex);
	$fet=mysql_fetch_array($ex);

		if($row==1)
		{
		    if( $fet['status'] == "1")
			{
			$_SESSION['id']=$fet['a_id'];
                        $_SESSION['name']=$fet['name'];
			header('location:home.php');
			}
			
			else
			
			{
			?>
<script>alert('in active');</script>
                    <?php
			}
			
			
		}
		else
		{
		?>
<script>alert('invalid email or passsword');</script>
                    <?php
		}
	}
	
	
?>



<div class="container" style="margin-top: 10%;">

    <!-- Modal -->
    <div  role="dialog">
        <div class="modal-dialog modal-sm">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                  
                    <h4 class="modal-title"><i class="fa fa-key"></i> Admin Login</h4>
                </div>
                <div class="modal-body">
                    <!-------- login--------------------->
                    <div class="container">
                        <br />
                        <form class="form-horizontal" role="form" action="" method="post" >
                            <div id="message_login"> </div>
                            <div class="form-group" >
                               
                                <div class="col-sm-15">          
                                    <input type="email" name="email" class="form-control"  placeholder="Enter Email" required="required">
                                </div>
                            </div>


                            <div class="form-group">
                    
                                <div class="col-sm-15">          
                                    <input type="password" name="pass" class="form-control"  placeholder="Enter password" required="required">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-sm-4"></span> </label>
                                <div class="col-sm-15">          

                                    <input type="submit"  name="login" class="btn btn-primary" style="width: 100%;" value="Login"/>
                                </div>
                            </div>


                             <div class="form-group">
                               
                                <div class="">          

                                    <a href="forgot.php" >forgot password?</a>
                                </div>
                            </div>
                            <br>
                           
                        </form>
                    </div>

                    <!---------------------------end------------>

                </div>
              
            </div>

        </div>
    </div>

</div>












<!-----------------end login--------------->

    
    </div>
  </body>
</html>
