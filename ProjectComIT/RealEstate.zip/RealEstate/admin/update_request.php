
<?php 
include("../include/connection.php");
?>
<?php
if(!isset($_SESSION['id']))
{
header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
   
    <title>Admin | </title>
 <link rel="stylesheet" type="text/css" href="dist/style/showToast.css" />
 <script type="text/javascript" src="dist/script/showToast.js"></script>
    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
             <a href="index.html" class="site_title"><span>Welcome <?php echo $_SESSION['name']?></span></a>
            </div>

          
            <br />

            <!-- sidebar menu -->
           <?php include"menu.php" ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">

              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Properties Detail</h3>
              </div>           
            </div>


            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2></h2>
                   
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">





                    <div class="container">
<br />



<?php
 $u_id=$_SESSION['u_id'];
 $p=$_REQUEST['up'];

               $q = mysql_query("select request.*,cities.city_name,Category_type from request join cities on request.city = cities.city_id join category on  request.Category_id = category.Category_id where p_id='$p'");
               $fet=mysql_fetch_array($q);
              

?>
<form class="form-horizontal" role="form" action="" id="uploadForm" method="post">
   <div id="m"> </div>

  
    <div class="form-group">
      <label class="control-label col-sm-2">Category:</label>
      <div class="col-sm-3">          
          <select  class="form-control" id="categoty" name="categoty">
            <option selectd value="0">Select Category</option>
          <?php
          
     $sel="select * from category ";
     $ex=mysql_query($sel);
     while($arr=mysql_fetch_array($ex))
     {
     ?>
            <option value="<?php echo $arr['Category_id'] ?>"
                    
                          <?php
        if($arr['Category_id']==$fet['Category_id'])
        {
          echo "selected='selected'";
        }
         ?>
                    
                    
                    
                    >
      
      <?php echo $arr['Category_type']; ?></option>
       <?php
     }
     ?>
      </select>
      </div>
    </div>
   
   <div class="form-group">
      <label class="control-label col-sm-2">Area:</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" onkeypress="return isfNumberKey(event)"  id="area" name="area" value="<?php echo $fet['area']; ?>" placeholder="Enter Area">
      </div>
    </div>
   
   <div class="form-group">
      <label class="control-label col-sm-2">Price:</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" onkeypress="return isfNumberKey(event)" id="price" name="price" value="<?php echo $fet['price']; ?>" placeholder="Enter Price">
      </div>
    </div>
   
   <div class="form-group">
      <label class="control-label col-sm-2">Bedrooms:</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" onkeypress="return isNumberKey(event)" id="bedrooms" name="bedrooms" value="<?php echo $fet['Bedrooms']; ?>" placeholder="Enter Bedrooms">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2">Action:</label>
      <div class="col-sm-3">          
          <select  class="form-control" id="action" name="action">
            <option selectd value="0">Select Action</option>
            <option value="Sell" <?php if($fet['action']=="Sell"){echo "selected='selected'";}?>>Sell</option>
            <option value="Rent" <?php if($fet['action']=="Rent"){echo "selected='selected'";}?>>Rent</option>
      </select>
          
      </div>
    </div>
  
   
   
  

   
   <div class="form-group">
      <label class="control-label col-sm-2">Description:</label>
      <div class="col-sm-3">          
      
          <textarea class="form-control" rows="5" id="address" name="address" ><?php echo $fet['des']; ?></textarea>
      </div>
    </div>
 
   <div class="form-group">
      <label class="control-label col-sm-2">City:</label>
      <div class="col-sm-3">          
          <select  class="form-control" id="fcity" name="fcity">
            <option selectd value="0">Select City</option>
       <?php
     $ci="select * from cities ORDER BY city_name ASC";
     $e1=mysql_query($ci);
     while($arr1=mysql_fetch_array($e1))
     {
     ?>
            <option value="<?php echo $arr1['city_id'] ?>"
                    
                    
                     <?php
        if($arr1['city_id']==$fet['city'])
        {
          echo "selected='selected'";
        }
         ?>
                    
                    >
      
      <?php echo $arr1['city_name']; ?></option>
       <?php
     }
     ?>
      </select>
          
      </div>
    </div>
   
    <div class="form-group">
      <label class="control-label col-sm-2">Mobile No:</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" onkeypress="return isNumberKey(event)" id="mobile" name="mobile" value="<?php echo $fet['mobile']; ?>" placeholder="Enter Mobil No">
      </div>
    </div>
   
   
   
   
      <div class="form-group">
      <label class="control-label col-sm-2"></span></label>
      <div class="col-sm-3">   
          
          <input type="submit" id="update_info" name="update" class="btn btn-success" style="width: 100%;" value="submit"/>
       
      </div>
    </div>
       
   
   <input type="hidden" name="pid" value="<?php echo $_REQUEST['up']; ?>" />
     
  </form>
</div>
                        </div>
                      
                      <script type="text/javascript">


  function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if ((charCode < 48 || charCode > 57))
     return false;

   return true;
 }

 function isfNumberKey(evt)
 {
  var charCode = (evt.which) ? evt.which : event.keyCode;
  if (charCode != 46 && charCode > 31 
    && (charCode < 48 || charCode > 57))
   return false;

 return true;
}





$(document).ready(function (e) {
  $("#uploadForm").on('submit',(function(e) {
            var categoty = $("#categoty").val();
            var area = $("#area").val();
            var price = $("#price").val();
            var bedrooms = $("#bedrooms").val();
           var action = $("#action").val();
            var address = $("#address").val();
            var fcity = $("#fcity").val();
             var mobile = $("#mobile").val();
         
         
              if(categoty=='0'){
                alert('Select category.');
    // showToastblack.show('Select category.',2000)
       $("#categoty").focus();
     return false;
   }

   else if(area==''){
     alert('Enter area.');
    // showToastblack.show('Enter area.',2000)
      $("#area").focus();
     return false;
   }

   else if(price==''){
     alert('Enter price.');
     //showToastblack.show('Enter price.',2000)
    $("#price").focus();
     return false;
   }

   else if(bedrooms==''){
     alert('Enter bedrooms..');
    // showToastblack.show('Enter bedrooms.',2000)
     $("#bedrooms").focus();
     return false;
   }

    else if(action=='0'){
 alert('select action.');
     $("#action").focus();
 return false;
}
 
 
   else if(address==''){
     alert('eter address.');
     //showToastblack.show('eter address.',2000)
      $("#address").focus();
     return false;
   }
   else if(fcity=='0'){
     alert('select city.');
    // showToastblack.show('select city.',2000)
         $("#fcity").focus();
     return false;
   }
   else if(mobile==''){
     alert('enter mobil no.');
    // showToastblack.show('enter mobil no.',2000)
       $("#mobile").focus();
     return false;
   }

   else if(mobile.length<10 || mobile.length>10 ){
//alert("enter mobil must be 10 digit");
 alert('enter mobil must be 10 digit');
//showToastblack.show('enter mobil must be 10 digit',2000)
    $("#mobile").focus();
return false;
   }

            else
            {
                   

    e.preventDefault();
                // document.getElementById("submit").value="Sending.....";
    $.ajax({
                        url: "request_update_request.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
                        cache: false,
      processData:false,
                        success: function(html)
                            {
                            $("#m").after(html);
                            //document.getElementById("submit").value="submit.";
                           
 
         
                            }  

           
                        });
                        
        }
  }));
});
</script>


                      
                
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include 'footer.php'; ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    
    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
  </body>
</html>
    
