<?php 
include("../include/connection.php");
?>
<?php
if(!isset($_SESSION['id']))
{
header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
   
    <title>Admin | </title>
 <link rel="stylesheet" type="text/css" href="dist/style/showToast.css" / >
 <script type="text/javascript" src="dist/script/showToast.js"></script>
    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
    

  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
             <a href="#" class="site_title"><span>Welcome <?php echo $_SESSION['name']?></span></a>
            </div>

          
            <br />

            <!-- sidebar menu -->
           <?php include"menu.php" ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            
            <!-- /menu footer buttons -->
          </div>
        </div>
 <?php 

      $old=$_POST['op'];
      $pass1=$_POST['np1'];
      $pass2=$_POST['np2'];
      
      $e=$_SESSION['id'];
      
      
      if(isset($_POST['change']))
      {
       
       if($pass1==$pass2)
       {
           $u1="select password from admin where a_id='$e'";
           $ex=mysql_query($u1);
           $re=mysql_fetch_array($ex);
           
           if($re['password']==$old)
           {
             $u="update admin set password='$pass2' where a_id='$e'";
             $ex1=mysql_query($u);
                        if($ex1)
                         {
                          ?>
                        <script>
                         alert('password change sucessfully');
                        </script>
                        <?php
                         }
                        else
                          {
                          ?>
                        <script>
                         alert('not change password');
                        </script>
                        <?php
                          }
          }
        else
        {
          ?>
          <script>
            alert('old password is invalid');
        </script>
        <?php
        
    }
    
}
else 
{
                ?>
          <script>
            alert('new password and new confirm password is not match');
        </script>
        <?php
}

}

?>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">

              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>patient detail</h3>
              </div>           
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                   
 
  
                      
                  <div id="login-modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
    <div class="modal-dialog modal-sm">

        <div class="modal-content">
            <div class="modal-header">
               
                <h4 class="modal-title" id="Login">change password</h4>
            </div>
            <div class="modal-body">
                <form action="" method="post">
                  
                    <div class="form-group">
                        <input type="text"   name="op"  class="form-control"  placeholder="Enter Old Password" required>
                    </div>
                    
                    <div class="form-group">
                        <input type="text"  name="np1"  class="form-control" placeholder="Enter password" required>
                    </div>
                    
                    <div class="form-group">
                        <input type="text"  name="np2"  class="form-control" placeholder="Enter Confirm password" required>
                    </div>
                    

                    <p class="text-center">
                        <input type="submit" name="change" value="change" class="btn btn-template-main"/>
                        
                    </p>

                </form>

                
            </div>
        </div>
    </div>
</div>
 

   
  
                      
                
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include 'footer.php'; ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    
    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
  </body>
</html>
    
