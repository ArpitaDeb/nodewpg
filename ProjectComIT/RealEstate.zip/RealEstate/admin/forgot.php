<?php 
include("../include/connection.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Gentelella Alela! | </title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
  
    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body >
    <div>
<!----------------login-------------------->

<?php 
	if(isset($_POST['forgot']))
	{
	
             $email=$_POST['email'];
                                $forgot="select * from admin where email='$email'";
				$ex=mysql_query($forgot);
				$row=mysql_num_rows($ex);
				$fet=mysql_fetch_array($ex); 
                                
                                    if($row==1)
					 {
                                        $password = $fet['password'];
					$to=$femail;
					$subject="forgot password";							
					$header="from: real estate <darshantank2012@gmail.com>";					
					$message.="your password is  ".$password;
					$sentmail = mail($to,$subject,$message,$header);
					            if($sentmail)
							 {
							 ?>
       
                                                          <script> alert('password send in your gmail account') </script>
					  		<?php
							 }
							 else
							 { 
							  ?>
                                                            <script> alert('Unable to send mail or check your email address') </script>
                                                               					
					  		<?php
							 }

			                 }
				    else
				     {
				?>
                                  <script> alert('email address not found or unregistered') </script>

				 <?php
 
				     }
			
            
	}
	
	
?>



<div class="container" style="margin-top: 10%;">

    <!-- Modal -->
    <div  role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                  
                    <h4 class="modal-title"><i class="fa fa-key"></i> forgot password</h4>
                </div>
                <div class="modal-body">
                    <!-------- login--------------------->
                    <div class="container">
                        <br />
                        <form class="form-horizontal" role="form" action="" method="post" >
                            <div id="message_login"> </div>
                            <div class="form-group" >
                                <label class="control-label col-sm-4">Email:</label>
                                <div class="col-sm-5">          
                                    <input type="email" name="email" class="form-control"  placeholder="Enter Email" required="required">
                                </div>
                            </div>


                           

                            <div class="form-group">
                                <label class="control-label col-sm-4"></span> </label>
                                <div class="col-sm-5">          

                                    <input type="submit"  name="forgot" class="btn btn-primary" style="width: 100%;" value="submit"/>
                                </div>
                            </div>


                            <br>
                           
                        </form>
                    </div>

                    <!---------------------------end------------>

                </div>
              
            </div>

        </div>
    </div>

</div>












<!-----------------end login--------------->

    
    </div>
  </body>
</html>
