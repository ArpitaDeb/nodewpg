<?php 
include("../include/connection.php");
?>
<?php
if(!isset($_SESSION['id']))
{
header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
   
    <title>Admin | </title>
 <link rel="stylesheet" type="text/css" href="dist/style/showToast.css" / >
 <script type="text/javascript" src="dist/script/showToast.js"></script>
    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
    

  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
             <a href="index.html" class="site_title"><span>Welcome <?php echo $_SESSION['name']?></span></a>
            </div>

          
            <br />

            <!-- sidebar menu -->
           <?php include"menu.php" ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">



              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>User Detail</h3>
              </div>           
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                 



                   
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      
                      
                      
                
                   
                         <?php

           $p=$_REQUEST['p'];
             // $u=$_REQUEST['u'];
              // $u=$_SESSION['u_id'];


         
?>

                

              <!------- ----------------------------------------------table---------------------------------------->
              <?php

              $count=0;
                 
     // $q = mysql_query("SELECT * FROM `rating` WHERE   property_id='$p' ");
       $q = mysql_query("SELECT rating.*,user.name FROM `rating` join user on user.u_id = rating.u_id  WHERE   property_id='$p' ");
    
              
      while($arr=mysql_fetch_array($q))
      {
         $a++;
         $count++;
      ?>
                  
      <tr>
    
         
         <td colspan="0"> 

              <div class="col-sm-4" align="center">  
                    <br>
                   
                    <?php 

                        if($arr['rating']==1)
                        {
                          ?>
                      
                       <img src="../images/1.png" width="100pt" > <br>
                       
                        <?php
                          }

                        else if ($arr['rating']==2) 
                        {
                         ?>
 <img src="../images/2.png" width="100pt" > <br>
  
                         <?php
                        }


                         else if ($arr['rating']==3) 
                        {
                         ?>
 <img src="../images/3.png" width="100pt" > </br>
  
                         <?php
                        }

                        else
                        {

                        }
                        ?>
                        
                    </div>


         </td>
     </tr>
                

                 
   <td width="62%" align="left">
         <br>
         <br>
      <br>
                      <?php echo '<b style="color: #423939;font-size: 14pt;">'."Review By ".$arr['name'].'</b>'.": ".$arr['message']; ?>
  
                
              
  </td>
  <br>
                  <hr style="background-color:#999966;">
                        <?Php
                        }



                   ?>
             
<?php
                  if($count==0)
{
  echo "<center>no any review added</center>";
}
     ?>
    

             

              
              
              <!--------------------------------------------------end table ---------------------------------------->
              
                
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include 'footer.php'; ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    
    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
  </body>
</html>
   