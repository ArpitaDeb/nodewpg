<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>

</head>

<body>
<?Php
//error_reporting(0);
include("../include/connection.php");

  $q = "select properties.*,cities.city_name,Category_type,user.name from properties join cities on properties.city = cities.city_id join category on  properties.Category_id = category.Category_id join user on  user.u_id = properties.u_id ORDER BY p_id ASC";
$re = mysql_query($q);

//search

  if($_POST['l'])
  {
    $l=$_POST['l'];
    $r=$_POST['r'];

    if($l=="category")
    {
     
      $q = "select properties.*,cities.city_name,Category_type,user.name from properties join cities on properties.city = cities.city_id join category on  properties.Category_id = category.Category_id join user on  user.u_id = properties.u_id  where category.Category_type like '%$r%' ORDER BY p_id ASC";
       $re = mysql_query($q);
    }

     if($l=="city")
    {
     
      $q = "select properties.*,cities.city_name,Category_type,user.name from properties join cities on properties.city = cities.city_id join category on  properties.Category_id = category.Category_id join user on  user.u_id = properties.u_id  where cities.city_name like '%$r%' ORDER BY p_id ASC";
       $re = mysql_query($q);
    }

     if($l=="action")
    {
     
      $q = "select properties.*,cities.city_name,Category_type,user.name from properties join cities on properties.city = cities.city_id join category on  properties.Category_id = category.Category_id join user on  user.u_id = properties.u_id  where properties.action like '%$r%' ORDER BY p_id ASC";
       $re = mysql_query($q);
    }

     if($l=="post")
    {
     
      $q = "select properties.*,cities.city_name,Category_type,user.name from properties join cities on properties.city = cities.city_id join category on  properties.Category_id = category.Category_id join user on  user.u_id = properties.u_id  where user.name like '%$r%' ORDER BY p_id ASC";
       $re = mysql_query($q);
    }

  }




$id=$_POST['s1'];
$stu=$_POST['s2'];
if($_POST['s2']=='1')
{
$a1="update properties set status='0' where p_id='$id'";
$v1=mysql_query($a1);
}
else
{
$a2="update properties set status='1' where p_id='$id'";
$v2=mysql_query($a2);
}


$d=intval($_POST['d']);
if($d)
{


                
                 $sel=mysql_query("SELECT * FROM `properties` WHERE p_id ='$d'");
                 $fet=mysql_fetch_array($sel);
                 unlink("../".$fet['pro_image']);
                  $sel1=mysql_query("SELECT * FROM `photo` WHERE p_id = '$d'");
                
                   while($a =  mysql_fetch_array($sel1))
                         {
                          unlink("../".$a['path']);

                         }

                        
                     $del1=mysql_query("DELETE FROM photo WHERE p_id = '$d'");
                     $del2=mysql_query("DELETE FROM properties WHERE p_id = '$d'");
                     $del3=mysql_query("DELETE FROM rating WHERE  property_id = '$d'");
                    
                  
}

?>
    

   <div class="container" style="overflow: scroll;" >
   
       <table class="table" id="dd">
    <thead>
      <tr>
         <th>id</th>
         <th>post by</th>
         <th>category</th>
        <th>mobile</th>
         <th>City</th>
         <th>Action</th>
         <th>Status</th>
       
      </tr>
    </thead>
    <tbody>
      <tr>
       <?Php
       $count=0;
       static $id=1;
while($row = mysql_fetch_object($re))
 {
  $count++;
 ?>
 
    <tr>
	<td> <?Php echo  $id ?></td>
  <td> <?Php echo  $row->name;?></td>
        <td> <?Php echo  $row->Category_type; ?></td>
       <td> <?Php echo  $row->mobile; ?></td>
       <td> <?Php echo  $row->city_name; ?></td>
       <td> <?Php echo  $row->action; ?></td>
        <td> 
             <?Php if( $row->status==1)
                     {
              ?>
             <div class="btn btn-success btn-xs">Active </div>
             <?php
                     }
                 else 
                     {
               ?>
             <div style="background-color:#ff1a1a" class="btn btn-warning btn-xs">Dective </div>
             <?php
                     }
                 
                 ?>
         
         </td>

        <td width="20" > <input type="button" name="delete" value="delete" onClick="del(<?php echo  $row->p_id; ?>);" class="btn btn-danger" /> </td>
 <td width="20" > <a href="update_property.php?up=<?php echo $row->p_id; ?>" class="btn btn-warning" >Edit </a> </td>
   <td width="20" > <a href="moredetail.php?p=<?php echo $row->p_id; ?>" class="btn btn-primary" >view </a> </td>
        <?Php 
              if($row->status=="0")
              {
                 
               ?>
        <td ><input type="button" name="active" value="active" id="st" onClick="status(<?php echo  $row->p_id; ?>,<?php echo  $row->status; ?>);" class="btn btn-info active" style="width: 60pt;"/> </td>
            <?Php
               }
	    else
	      {
	     ?>
   <td><input type="button" name="dactive"  id="st" value="deactive" onClick="status(<?php echo  $row->p_id; ?>,<?php echo  $row->status; ?>);" class="btn btn-info active"   /> </td>
          <?Php
             }
             ?>
       
  
    </tr>
	<?Php
	$id++;
}
?>
      </tr>
    </tbody>
  </table>
</div>
    
    
    
<?php 

if($count==0)
{
  echo "<center>data not fount</center>";
}
?>



</body>
</html>
