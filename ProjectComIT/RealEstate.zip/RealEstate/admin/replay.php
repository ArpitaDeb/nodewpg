
<?php 
include("../include/connection.php");
?>
<?php
if(!isset($_SESSION['id']))
{
  header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

  <title>Admin | </title>
  <link rel="stylesheet" type="text/css" href="dist/style/showToast.css" />
  <script type="text/javascript" src="dist/script/showToast.js"></script>
  <!-- Bootstrap -->
  <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">


  <!-- Custom Theme Style -->
  <link href="build/css/custom.min.css" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

</head>

<body class="nav-md">
  <div class="container body">
    <div class="main_container">
      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">
          <div class="navbar nav_title" style="border: 0;">
           <a href="index.html" class="site_title"><span>Welcome <?php echo $_SESSION['name']?></span></a>
         </div>


         <br />

         <!-- sidebar menu -->
         <?php include"menu.php" ?>
         <!-- /sidebar menu -->

         <!-- /menu footer buttons -->

         <!-- /menu footer buttons -->
       </div>
     </div>

     <!-- top navigation -->
     <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle">
            <a id="menu_toggle"><i class="fa fa-bars"></i></a>
          </div>

          <ul class="nav navbar-nav navbar-right">

          </ul>
        </nav>
      </div>
    </div>
    <!-- /top navigation -->

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Properties Detail</h3>
          </div>           
        </div>


        <div class="clearfix"></div>

        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2></h2>

                <div class="clearfix"></div>
              </div>

              <div class="x_content">
                <div style="margin-left: 200px" class="container" >
                  <br />

                  <?php
                  $id=$_REQUEST['r'];
                  $q=mysql_query("select * from feedback where f_id='$id'");
                  $fet=mysql_fetch_array($q);
                  $femail= $fet['email'];

                  if(isset($_REQUEST['replay']))
                  {
                    $rep_mess = $_REQUEST['reptext'];
                    $to=$femail;
                    $subject="Feedback Replay";             
                    $header="from: real estate <darshantank2012@gmail.com>";          
                    $message.=" ".$rep_mess;
                    $sentmail = mail($to,$subject,$message,$header);
                    if($sentmail)
                    {
                     ?>
                     <script> alert('replay send succefuly') </script>
                     <?php
                   }
                   else
                   { 
                    ?>
                    <script> alert('replay not send') </script>

                    <?php
                  }

                }




                ?>





                <form class="form-horizontal" role="form" action=""  method="post">





                 <div class="form-group">
                  <label class="control-label col-sm-2">Replay message:</label>
                  <div class="col-sm-3">          

                    <textarea class="form-control" rows="5" id="address" name="reptext" ></textarea>
                  </div>
                </div>



                <div class="form-group">
                  <label class="control-label col-sm-2"></span></label>
                  <div class="col-sm-3">   

                    <input type="submit"  name="replay" class="btn btn-success" style="width: 100%;" value="submit"/>

                  </div>
                </div>




              </form>
            </div>





          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content -->

<!-- footer content -->
<?php include 'footer.php'; ?>
<!-- /footer content -->
</div>
</div>

<!-- jQuery -->
<script src="vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>


<!-- Custom Theme Scripts -->
<script src="build/js/custom.min.js"></script>
</body>
</html>

