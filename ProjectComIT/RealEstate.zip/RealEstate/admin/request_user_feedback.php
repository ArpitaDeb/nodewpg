<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>

</head>

<body>
<?Php
//error_reporting(0);
include("../include/connection.php");

$sq="SELECT * FROM feedback";
$re = mysql_query($sq);
$d=intval($_POST['d']);

if($d)
{
 mysql_query("DELETE FROM `feedback` WHERE  f_id = $d ");

}


?>
    

   <div class="container" style="overflow: scroll;" >
   
       <table class="table" id="dd" >
    <thead>
      <tr>
         <th>id</th>
         <th>name</th>
        <th>email</th>
        <th style="width:400px;">message</th>
      </tr>
    </thead>
    <tbody>
      <tr>
       <?Php
       $count=0;
       static $id=1;
while($row = mysql_fetch_object($re))
 {
  $count++;
 ?>
 
    <tr>
	<td> <?Php echo  $id ?></td>
        <td > <?Php echo  $row->name; ?></td>
        <td > <?Php echo  $row->email;?></td>
        <td > <?Php echo  $row->feedback;?></td>
        <td  > <input type="button" name="delete" value="delete" onClick="del(<?php echo  $row->f_id; ?>);" class="btn btn-danger" /> </td>
 <td  > <a href="replay.php?r=<?Php echo $row->f_id;?> " class="btn btn-primary" target="_blank"/>Replay </td>
       
  
    </tr>
	<?Php
	$id++;
}
?>
      </tr>
    </tbody>
  </table>
</div>
    
    <?php 

if($count==0)
{
  echo "<center>data not fount</center>";
}
     ?>
    


</body>
</html>
