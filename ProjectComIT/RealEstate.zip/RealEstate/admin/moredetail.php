<?php 
include("../include/connection.php");
?>
<?php
if(!isset($_SESSION['id']))
{
  header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
 
  <title>Admin | </title>
  <link rel="stylesheet" type="text/css" href="dist/style/showToast.css" />
  <script type="text/javascript" src="dist/script/showToast.js"></script>
  <!-- Bootstrap -->
  <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">


  <!-- Custom Theme Style -->
  <link href="build/css/custom.min.css" rel="stylesheet">
  

</head>

<body class="nav-md">
  <div class="container body">
    <div class="main_container">
      <div class="col-md-3 left_col">
        <div class="left_col scroll-view">
          <div class="navbar nav_title" style="border: 0;">
           <a href="index.html" class="site_title"><span>Welcome <?php echo $_SESSION['name']?></span></a>
         </div>

         
         <br />

         <!-- sidebar menu -->
         <?php include"menu.php" ?>
         <!-- /sidebar menu -->

         <!-- /menu footer buttons -->
         
         <!-- /menu footer buttons -->
       </div>
     </div>

     <!-- top navigation -->
     <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle">
            <a id="menu_toggle"><i class="fa fa-bars"></i></a>
          </div>

          <ul class="nav navbar-nav navbar-right">

          </ul>
        </nav>
      </div>
    </div>
    <!-- /top navigation -->

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Properties Detail</h3>
          </div>           
        </div>

        <div class="clearfix"></div>

        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2></h2>
                <div class="container">
                
             </div>
             <div class="clearfix"></div>
           </div>
           <div class="x_content">
            

           <?php
              $p=$_REQUEST['p'];

               $q = mysql_query("select properties.*,cities.city_name,countries.country_name,states.state_name,Category_type from properties 
                join cities on properties.city = cities.city_id 
                 join states on cities.state_id = states.state_id 
                join countries on  states.country_id  = countries.country_id
                join category on  properties.Category_id = category.Category_id where p_id=$p");
               //$q = mysql_query("SELECT * FROM `properties`");
      while($arr=mysql_fetch_object($q))
      {
                            $a++;
      ?>
                  
                   <tr >
         
         <td colspan="0"> <div style="font-size: 15pt;color: black;" ><?php echo $arr->address; ?></div></td>
     </tr>
                <div class="col-sm-4" align="center">  
                    <br>
                    
                    <?Php 
                    if($arr->pro_image=="")
                    {
                     ?>
                    <img src="../images/images.png" width="300" height="200" draggable="false"/> 
                     <?php
                    }
                    else 
                        {?>
                     <img src="<?php echo "../".$arr->pro_image; ?>"width="300" height="200" draggable="false"/> 
     
                    <?php
                        }
                     ?>
                    </div>

                 
   <td width="62%" align="left">
         
      <br>
                      <i class="fa fa-inr" aria-hidden="true"></i>  <?php echo $arr->price." - ".$arr->Bedrooms."BHK ,".$arr->city_name; ?><br><br>
                   
                 

                      <i class="fa fa-star" aria-hidden="true"></i> <?php echo $arr->action; ?><br><br>

                        <i class="fa fa-area-chart" aria-hidden="true"></i> <?php echo $arr->area." sqft"; ?><br><br>
                    <i class="fa fa-globe" aria-hidden="true"></i> <?php echo $arr->country_name.", ".$arr->state_name; ?><br><br>
                    <i class="fa fa-phone" aria-hidden="true"></i> <?php echo $arr->mobile; ?><br><br>

                        <div style="text-align: right;"><a href="review.php?p=<?php echo $arr->p_id; ?>"  target="_blank" class="btn btn-info btn-sm"><i class="fa fa-th-large"></i> view reviews </a></div>
                       
               
  </td>
  <br>
                  <hr style="background-color:#999966;">
                        <?Php
                        }
                   ?>
             
                 
                  <div style="font-size: larger;">more images<div>
              
                          <br>
                          
                          <?php
                          
               static $a=1;
               $qq = mysql_query("SELECT * FROM `photo` WHERE p_id='$p'"); 
               ?>
            
                          <div class="container" style="text-align: center;">
                        <?php
                        $a++;
      while($a=mysql_fetch_object($qq))
      {
             ?>
                              <img src="<?php echo "../".$a->path;?>" class="img-rounded" alt="Cinque Terre" width="300" height="300" style="margin-top: 20px;margin-left: 10pt;">
                
                          <?php
                          }
                          ?>
           
                   </div>
             

              
              
              <!--------------------------------------------------end table ---------------------------------------->
              
            
                 
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content -->

<!-- footer content -->
<?php include 'footer.php'; ?>
<!-- /footer content -->
</div>
</div>

<!-- jQuery -->
<script src="vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>


<!-- Custom Theme Scripts -->
<script src="build/js/custom.min.js"></script>
</body>
</html>
<script>

</script>