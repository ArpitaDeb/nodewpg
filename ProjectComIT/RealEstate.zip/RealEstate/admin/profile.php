<?php 
include("../include/connection.php");
?>
<?php
if(!isset($_SESSION['id']))
{
header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
   
    <title>Admin | </title>
 <link rel="stylesheet" type="text/css" href="dist/style/showToast.css" / >
 <script type="text/javascript" src="dist/script/showToast.js"></script>
    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
    

  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
             <a href="index.html" class="site_title"><span>Welcome <?php echo $_SESSION['name']?></span></a>
            </div>

          
            <br />

            <!-- sidebar menu -->
           <?php include"menu.php" ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            
            <!-- /menu footer buttons -->
          </div>
        </div>
 

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">

              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->
<?php
if(isset($_REQUEST["edit"]))
{
$id=$_SESSION['id'];
$name =$_POST['name'];
$email =$_POST['email'];




$u="update admin set name='$name',email='$email' where a_id='$id'";
$ex2=mysql_query($u);
 if($ex2)
 {
     ?>
            <script> alert('profile update sucessfully'); </script>
     <?php
     
 }
 else
  {
     ?>
            <script> alert('not update your profile'); </script>
     <?php
     
 }
//header("location:profile.php");
}



 ?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>patient detail</h3>
              </div>           
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 
                  <div class="x_content">
                   
 
            <?php 
             $id=$_SESSION['id'];
            $q="SELECT * FROM `admin` WHERE a_id='$id'";
            $ex=mysql_query($q);
            $ar=mysql_fetch_array($ex);
            ?>

  <div id="login-modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
    <div class="modal-dialog modal-sm">

        <div class="modal-content">
            <div class="modal-header">
             
                <h4 class="modal-title" id="Login">Patient profile</h4>
            </div>
            <div class="modal-body">
                <form action="" method="post">
                    
                 <div class="form-group">
                     <input type="text"   name="name"  value="<?php echo $ar['name']; ?>"  class="form-control"  placeholder="Enter Name" required>
                </div>
                    
                <div class="form-group">
                    <input type="email"   name="email" value="<?php echo $ar['email']; ?>" class="form-control"  placeholder="Enter email" required>
                </div>
                
              
              


             <p class="text-center">
                <input type="submit" name="edit" value="edit" class="btn btn-template-main"/>
                
            </p>

        </form>

       

    </div>
</div>
</div>
</div>
   
 

   
  
                      
                
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include 'footer.php'; ?>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    
    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
  </body>
</html>
    
