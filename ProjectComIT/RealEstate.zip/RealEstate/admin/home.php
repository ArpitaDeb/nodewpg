<?php
include("../include/connection.php");
?>
<?php
if(!isset($_SESSION['id']))
{
header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
   
    <title>Admin | </title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">


    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.html" class="site_title"><span>Welcome <?php echo $_SESSION['name']?></span></a>
            </div>

          
            <br />

            <!-- sidebar menu -->
           <?php include"menu.php" ?>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">

              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>home</h3>
              </div>           
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <?php

                    $re = mysql_query("SELECT * FROM properties");
              static $p=0;
              while($row = mysql_fetch_object($re)) {$p++;}


$re1 = mysql_query("SELECT * FROM user where user_type='1'");
              static $a=0;
              while($row = mysql_fetch_object($re1)) {$a++;}

$re2 = mysql_query("SELECT * FROM user where user_type='2'");
              static $c=0;
              while($row = mysql_fetch_object($re2)) {$c++;}


                    ?>


                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                     <div class="container-fluid">
  
  <div class="row" >

    <div class="col-sm-4"   ><div class="btn btn-primary btn-lg btn-block" style="padding: 59px 45px;"><i class="fa fa-user fa-3x"> </i> Total Agent:   <?php echo $a; ?></div></div>

    <div class="col-sm-4" ><div class="btn btn-warning btn-lg btn-block" style="padding: 59px 45px;"><i class="fa fa-user fa-3x"></i> Total Customer  <?php echo $c;  ?></div></div>

    <div class="col-sm-4" ><div class="btn btn-primary btn-lg btn-block" style="padding: 59px 45px;"><i class="fa fa-product-hunt fa-3x"></i> Total Propertys <?php echo $p;  ?></div></div>

  </div>

</div>

                      
                    


                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    
    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
  </body>
</html>
