<div class="top-header hidden-xs">
        <div class="container">
          <div class="row">
            <div class="col-md-4 col-sm-6">
              <ul class="horiz-nav pull-left">
               
              </ul>
            </div>
            
            <div class="col-md-8 col-sm-6">
              <ul class="horiz-nav pull-right">
                <li><a href="#" ><i class="fa fa-instagram"></i></a></li>
                <li><a href="#" ><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              </ul>
            </div>
            
          </div>
        </div>
      </div>