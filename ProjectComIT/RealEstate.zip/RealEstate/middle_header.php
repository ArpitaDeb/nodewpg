<div class="middle-header">
        <div class="container">
          <div class="row">
            <div class="col-md-4 col-sm-8 col-xs-8">
              <?php include("logo.php");?>
            </div>
            <div class="col-md-8 col-sm-4 col-xs-4">
              <div class="contact-info-blocks hidden-sm hidden-xs">
                <div>
                  <i class="fa fa-phone"></i> Free Line For You
                  <span>+ 91 1234567891</span>
                </div>
                <div>
                  <i class="fa fa-envelope"></i> Email Us
                  <span>RealEstate@gmail.com</span>
                </div>
                
              </div>
              <a href="#" class="visible-sm visible-xs menu-toggle"><i class="fa fa-bars"></i></a>
            </div>
          </div>
        </div>
      </div>