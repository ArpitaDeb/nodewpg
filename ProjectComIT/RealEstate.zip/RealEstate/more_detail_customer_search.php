
 <?php include("include/connection.php");?>

<?php
if(!isset($_SESSION['u_id']))
{
header("location:index.php");
}
?>
 <!DOCTYPE HTML>
 <html class="no-js">
 <head>
<!-- Basic Page Needs
  ================================================== -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Real Estate</title>
  <link rel="icon" type="image/png" href="favicon.png">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="format-detection" content="telephone=no">
<!-- CSS
  ================================================== -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
  <!-- Color Style -->
  <link class="alt" href="colors/color1.css" rel="stylesheet" type="text/css">
  <link href="style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
<!-- SCRIPTS
  ================================================== -->
  <script src="js/modernizr.js"></script><!-- Modernizr -->
  
</head>
<body class="home">

  <div class="body">
    <!-- Start Site Header -->
    <!-- Start Site Header -->
    <header class="site-header">

      <?php include("top_header.php");?>
      
      <?Php include("middle_header.php");?>

      <?php include("menu.php");?>
         <?php include_once("include/signup.php");?>
        <?Php include_once("include/login.php"); ?>
        <?Php include_once("include/forgotpass.php"); ?>

<div class="container">

        <!-- Modal -->
        <div class="modal fade" id="rating_model" role="dialog">
          <div class="modal-dialog modal-sm">

            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Rating</h4>
              </div>
              <div class="modal-body">
<?php

        //$se=("SELECT * FROM `rating` WHERE u_id='$uid' AND  property_id='$pid' ");  
         //$s=mysql_query($se); 
      //   $ro= mysql_num_rows($s);

         ?>
                    <!-------- login--------------------->
                    <div class="container">
                        <br />
                        <form class="form-horizontal" role="form"  id="ratingForm">
                            <div id="message_rating"> </div>
                            <div class="form-group" align="center" >
                                  
                                <div class="col-sm-2">




                                 <input type="hidden"  id="pid"  name="pid" value="" placeholder="Enter id"/>
                                <img src="images/1.png" width="200pt" align="center" >
                                              <input type="radio" name="rat" id="rat" value="1" align="center" width="100pt" >
                                 </div>



                                  <div class="col-sm-2">
                                  <img src="images/2.png" width="200pt" > 
                                      <input type="radio" name="rat" id="rat"  align="center" value="2" checked="checked">

                                  </div>



                                    <div class="col-sm-2">
                                    <img src="images/3.png"  width="200pt">
                                         <input type="radio" name="rat" id="rat" align="center" value="3">

                                     </div>
                            </div>


                            <div class="form-group">
                                 
                                <div class="col-sm-6">          
                                 <label for="comment">Comment:</label>
                        <textarea class="form-control" rows="5" id="comment" name="comment"></textarea>
                                </div>
                            </div>

                            <div class="form-group">
                            
                                <div class="col-sm-6">          

                                    <input type="submit"  name="submit" id="submit" class="btn btn-success" style="width: 100%;" value="submit"/>
                                </div>
                            </div>


                            <br>
                          
                        </form>
                    </div>

                    <!---------------------------end------------>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                  </div>
                </div>

              </div>
            </div>

          </div>
          <script type="text/javascript">
           function rating(pid)
           {
            document.getElementById('pid').value=pid;

            $("#rating_model").modal();

          }

        </script>


        
        
        
        
    </header>
    <!-- End Site Header -->
    <!-- End Site Header -->
    <!-- Site Showcase -->

    <!-- End Hero Slider --> 
    <!-- Site Search Module -->
    

</div>
    
   <!--- end search ----------------->
   
   
    <!-- Start Content -->
    <div class="main" role="main">
      <div id="content" class="content full">
        <div class="featured-blocks">
            <div class="container" >
            <?php

             $p=$_REQUEST['p'];
              $u=$_REQUEST['u'];
               $u=$_SESSION['u_id'];

 $se=("SELECT * FROM `rating` WHERE u_id=' $u' AND  property_id='$p' ");  
         $s=mysql_query($se); 
         $row= mysql_num_rows($s);
         $ratarray= mysql_fetch_array($s);

         
?>

                

              <!------- ----------------------------------------------table---------------------------------------->
              <?php
             
              
               $q = mysql_query("select properties.*,cities.city_name,countries.country_name,states.state_name,Category_type from properties 
                join cities on properties.city = cities.city_id 
                join states on cities.state_id = states.state_id 
                join countries on  states.country_id  = countries.country_id
                join category on  properties.Category_id = category.Category_id where p_id=$p");
               //$q = mysql_query("SELECT * FROM `properties`");
			while($arr=mysql_fetch_object($q))
			{
                            $a++;
			?>
                  
                   <tr >
                   <div style="text-align: right;"><a href="#" class="btn btn-warning btn-sm"  onClick="rating(<?php echo $arr->p_id;?>); "><i class="fa fa-star"></i> Give Rating </a></div>
         
         <td colspan="0"> <div style="font-size: 15pt;color: #0052cc;" ><?php echo $arr->address; ?></div></td>
     </tr>
                <div class="col-sm-4" align="center">  
                    <br>
                    
                    <?Php 
                    if($arr->pro_image=="")
                    {
                     ?>
                    <img src="images/images.png" width="200" height="100" draggable="false"/> 
                     <?php
                    }
                    else 
                        {?>
                     <img src="<?php echo $arr->pro_image; ?>" width="500" height="270" draggable="false"/> 
     
                    <?php
                        }
                     ?>
                    </div>

                 
   <td width="62%" align="left">
         
      <br>
                      <i class="fa fa-inr" aria-hidden="true"></i>  <?php echo $arr->price." - ".$arr->Bedrooms."BHK ,".$arr->city_name; ?><br><br>
                   
                 

                      <i class="fa fa-star" aria-hidden="true"></i> <?php echo $arr->action; ?><br><br>

                        <i class="fa fa-area-chart" aria-hidden="true"></i> <?php echo $arr->area." sqft"; ?><br><br>
                    <i class="fa fa-globe" aria-hidden="true"></i> <?php echo $arr->country_name.", ".$arr->state_name; ?><br><br>
                    <i class="fa fa-phone" aria-hidden="true"></i> <?php echo $arr->mobile; ?><br><br>
                        
                        <?php 

                        if($ratarray['rating']==1)
                        {
                          ?>
                      
                        <?php echo '<b style="color: #423939;font-size: 14pt;">'."your review: ".'</b>'?><img src="images/1.png" width="50pt" > <br>
                        <?php echo '<b style="color: #423939;font-size: 14pt;">'."comment:".'</b>'.$ratarray['message']; ?>
                        <?php
                          }

                        else if ($ratarray['rating']==2) 
                        {
                         ?>
 <?php echo '<b style="color: #423939;font-size: 14pt;">'."your review: ".'</b>'?><img src="images/2.png" width="50pt" > <br>
   <?php echo '<b style="color: #423939;font-size: 14pt;">'."comment:".'</b>'.$ratarray['message']; ?>
                         <?php
                        }


                         else if ($ratarray['rating']==3) 
                        {
                         ?>
 <?php echo '<b style="color: #423939;font-size: 14pt;">'."your review: ".'</b>'?><img src="images/3.png" width="50pt" > </br>
   <?php echo '<b style="color: #423939;font-size: 14pt;">'."comment:".'</b>'.$ratarray['message']; ?>
                         <?php
                        }

                        else
                        {

                        }
                        ?>
                        
                 
                    
                      

 

 <div style="text-align: right;"><a href="review_display_login.php?p=<?php echo $arr->p_id; ?>"  target="_blank" class="btn btn-info btn-sm"><i class="fa fa-th-large"></i> view reviews </a></div>

              
               
              
  </td>
  <br>


                  <hr style="background-color:#999966;">




                        <?Php
                        }
                   ?>
             


                 
                  <div style="font-size: larger;">more images<div>
              
                          <br>
                          
                          <?php
                          
               static $a=1;
               $qq = mysql_query("SELECT * FROM `photo` WHERE p_id='$p'"); 
               ?>
            
                          <div class="container" style="text-align: center;">
                        <?php
                        $a++;
			while($a=mysql_fetch_object($qq))
			{
		         ?>
                              <img src="<?php echo $a->path;?>" class="img-rounded" alt="Cinque Terre" width="300" height="300" style="margin-top: 20px;margin-left: 10pt;">
                
                          <?php
                          }
                          ?>
           
                   </div>
             

              
              
              <!--------------------------------------------------end table ---------------------------------------->
              
              
              
              
              
          </div>
        </div>
    
     



       
       <!-- End Site Footer -->
       <a id="back-to-top"><i class="fa fa-angle-double-up"></i></a>
     </div>
      </div>
         <footer class="site-footer-bottom">
         <?Php include("footer.php");?>
       </footer>
     <script src="js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call --> 
     <script src="plugins/flexslider/js/jquery.flexslider.js"></script> <!-- FlexSlider --> 
     <script src="js/helper-plugins.js"></script> <!-- Plugins --> 
     <script src="js/bootstrap.js"></script> <!-- UI --> 
     <script src="js/waypoints.js"></script> <!-- Waypoints --> 
     <script src="js/init.js"></script> <!-- All Scripts -->
     <!--[if lte IE 9]><script src="js/script_ie.js"></script><![endif]--> 


   </body>

   </html>


  




<?php include_once("include/validation.php"); ?>
    <script>
 $(document).ready(function (e) {
          $("#ratingForm").on('submit',(function(e) {
            var comment = $("#comment").val();
            var pid = $("#pid").val();
            var rat = $("#rat").val();


            if(rat==''){
             showToastblack.show('select rating face .',2000)
            // $("#comment").focus();
             return false;
           }

            else if(comment==''){
             showToastblack.show('enter comment .',2000)
             $("#comment").focus();
             return false;
           }


           else
           {


            e.preventDefault();
            document.getElementById("submit").value="submiting.....";
            $.ajax({
              url: "request_rating.php",
              type: "POST",
              data:  new FormData(this),
              contentType: false,
              cache: false,
              processData:false,
              success: function(html)
              {
                $("#message_rating").after(html);
                document.getElementById("submit").value="submit";
                document.getElementById("comment").value='';
                 document.getElementById('rat').checked=false;
     


   }  


 });

          }
        }));
        });
      </script>