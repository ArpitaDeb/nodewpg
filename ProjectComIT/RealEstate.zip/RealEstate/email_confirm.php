
 <?php include_once("include/connection.php"); ?>
<?php

$passkey=$_GET['passkey'];
$sql="SELECT * FROM user WHERE verification_code ='$passkey'";
$result=mysql_query($sql);

$r=mysql_num_rows($result);
$f=mysql_fetch_array($result);
 $email=$f['email'];

if($r==1)
{
     $up=("update user set verification_status='1' where verification_code ='$passkey'");	
        $u1=mysql_query($up);
        
        $u=("update user set verification_code ='7c046lqe' where email ='$email'");	
        $u=mysql_query($u);
        
       echo "your account is verified";
}
else
{
      echo "Invalid link";
}

?>





