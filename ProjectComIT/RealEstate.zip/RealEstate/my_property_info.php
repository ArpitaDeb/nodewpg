 <?php include("include/connection.php");?>

<?php
if(!isset($_SESSION['u_id']))
{
header("location:index.php");
}
?>
 <!DOCTYPE HTML>
 <html class="no-js">
 <head>
<!-- Basic Page Needs
  ================================================== -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Real Estate</title>
  <link rel="icon" type="image/png" href="favicon.png">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="format-detection" content="telephone=no">
<!-- CSS
  ================================================== -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
  <!-- Color Style -->
  <link class="alt" href="colors/color1.css" rel="stylesheet" type="text/css">
  <link href="style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
<!-- SCRIPTS
  ================================================== -->
  <script src="js/modernizr.js"></script><!-- Modernizr -->
  
</head>
<body class="home">

  <div class="body">
    <!-- Start Site Header -->
    <!-- Start Site Header -->
    <header class="site-header">

      <?php include("top_header.php");?>
      
      <?Php include("middle_header.php");?>

      <?php include("menu.php");?>
         
    </header>

    <!-- Start Content -->
    <div class="main" role="main">
      <div id="content" class="content full">
        <div class="featured-blocks">
        
         
  
              
              <div class="container">

                  
                  
 <div id="txtHint" style=""> </div>


 
    
        
                <!---end                                                                      contant------->
                
          </div>
        </div>
       


         <div class="padding-tb45 bottom-blocks">
          <div class="container">

          </div>
        </div>

       
       <!-- End Site Footer -->
       <a id="back-to-top"><i class="fa fa-angle-double-up"></i></a>
     </div>
    </div>
         <footer class="site-footer-bottom">
         <?Php include("footer.php");?>
       </footer>
     <script src="js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call --> 
     <script src="plugins/flexslider/js/jquery.flexslider.js"></script> <!-- FlexSlider --> 
     <script src="js/helper-plugins.js"></script> <!-- Plugins --> 
     <script src="js/bootstrap.js"></script> <!-- UI --> 
     <script src="js/waypoints.js"></script> <!-- Waypoints --> 
     <script src="js/init.js"></script> <!-- All Scripts -->
     <!--[if lte IE 9]><script src="js/script_ie.js"></script><![endif]--> 


   </body>

   </html>
   
<script>
    
    function showtable()
  {

  if (window.XMLHttpRequest) 
   {
    xmlhttp=new XMLHttpRequest();
   }
   else
   
 { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() 
{ 
    if (xmlhttp.readyState==4 && xmlhttp.status==200) 
    {
      document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
	     
  }
  
 xmlhttp.open("POST","responce_property_info.php",true);
 xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlhttp.send();
  

}

showtable();
    
function del(d)
 {

  
  if (window.XMLHttpRequest) 
   {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
   else
   
 { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	
  }
  xmlhttp.onreadystatechange=function() 
{
  
    if (xmlhttp.readyState==4 && xmlhttp.status==200) 
   {
  
	
     document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
      showtable()
		
    }
	     
  }
  
     if (confirm("do you want to Delete?!") == true) 
            {
	 
  xmlhttp.open("POST","responce_property_info.php",true);
  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xmlhttp.send("alldel="+d);
            }
  
}

   
   
function status(s1,s2)
 {
  var x;

 
  if (window.XMLHttpRequest) 
   {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
   else
   
 { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	
  }
  xmlhttp.onreadystatechange=function() 
{
  
    if (xmlhttp.readyState==4 && xmlhttp.status==200) 
   {


     document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
     showtable()
    } 
    
  }  
   
	if (confirm("do you want to change status?!") == true) 
            {
	 
         
         xmlhttp.open("POST","responce_property_info.php",true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
              xmlhttp.send("s1="+s1+"&s2="+s2);
            
   
          }
}
  
           
</script>