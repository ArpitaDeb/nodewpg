<style>
    .modal-header, h4, .close {
        background-color: #FF4D4D;
        color:white !important;
        text-align: center;
        font-size: 30px;
    }

</style>
<div class="container">

    <!-- Modal -->
    <div class="modal fade" id="forgot_model" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><span class="glyphicon glyphicon-lock"></span> Forgot Password</h4>
                </div>
                <div class="modal-body">
                    <!-------- login--------------------->
                    <div class="container">
                        <br />
                        <form class="form-horizontal" role="form" action="" >
                            <div id="message_f"> </div>
                            <div class="form-group" >
                                <label class="control-label col-sm-2"></span> Email:</label>
                                <div class="col-sm-3">          
                                    <input type="email" class="form-control" id="femail" placeholder="Enter Email">
                                </div>
                            </div>



                            <div class="form-group">
                                <label class="control-label col-sm-2"></span> </label>
                                <div class="col-sm-3">          

                                    <input type="button" id="forgot" name="forgot" class="btn btn-success" style="width: 100%;" value="Send"/>
                                </div>
                            </div>


                        </form>
                    </div>

                    <!---------------------------end------------>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

</div>

<script>

    function forgot_password()
    {
        $("#login_model").modal("hide");
        $("#forgot_model").modal();

    }
</script>