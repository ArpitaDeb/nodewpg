
<style>
  .modal-header, h4, .close {
    background-color: #FF4D4D;
    color:white !important;
    text-align: center;
    font-size: 30px;
    
  }

</style>

<?php 
$chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$randomString = '';

for ($i = 0; $i < 4; $i++) 
{
  $randomString .= $chars[rand(0, strlen($chars))];
}

if(strlen($randomString)==3)
{
 $randomString .='z';
}

?>
<div class="container">

  <!-- Modal -->
  <div class="modal fade" id="signup_model" role="dialog">
    <div class="modal-dialog">
      
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Register</h4>
        </div>
        <div class="modal-body">
		<!-------- login--------------------->
		<div class="container">
<br />
  <form class="form-horizontal" role="form" method="post" name="reg">
      <div id="message"> </div>
   <div class="form-group">
      <label class="control-label col-sm-2">Name:</label>
      <div class="col-sm-3">          
        <input type="text" id="rname" class="form-control"  placeholder="Enter Name" onkeypress="return RestrictSpace()">
      </div>
    </div>
  
   <div class="form-group" >
      <label class="control-label col-sm-2">Email:</label>
      <div class="col-sm-3">          
        <input type="email" class="form-control" id="remail" placeholder="Enter Email" onkeypress="return RestrictSpace()">
      </div>
    </div>
  
  
    <div class="form-group">
      <label class="control-label col-sm-2">Password:</label>
      <div class="col-sm-3">          
        <input type="password" class="form-control" id="rpassword1" placeholder="Enter Password" onkeypress="return RestrictSpace()">
      </div>
    </div>
	
	 <div class="form-group">
      <label class="control-label col-sm-2">Confirm Password:</label>
      <div class="col-sm-3">          
        <input type="password" class="form-control" id="rpassword2" placeholder="Confirm Password" onkeypress="return RestrictSpace()">
      </div>
    </div>
	
	<div class="form-group">
      <label class="control-label col-sm-2">Mobile No:</label>
      <div class="col-sm-3">          
        <input type="text" class="form-control" id="rmobil" placeholder="Enter Mobile Number." onkeypress="return isNumberKey(event)" maxlength="10">
      </div>
    </div>
	
	<div class="form-group">
      <label class="control-label col-sm-2">User Type</label>
      <div class="col-sm-3">          
     <select class="form-control" id="rselect_user">
       <option value="0" selected>select user type</option>
       <option value="1">Agent</option>
       <option value="2">customer</option>
     
    </select>
      </div>
    </div>
	
    <div class="form-group">
       <label class="control-label col-sm-2"></label>
        <div class="col-sm-3">
        <input type="text" value="<?php echo $randomString;?>" style="font-size:30px;font-style:italic;font-weight:900;letter-spacing:1px;text-shadow:#3300FF;text-align:left;width:150px;border-top:hidden;border-left:hidden;border-right:hidden;border-bottom-style:none;" readonly="" id="rcode1"/>
            </div>
    </div>
	
    
    <div class="form-group">
      <label class="control-label col-sm-2">Enter Captcha Code:</label>
      <div class="col-sm-3">          
        <input type="text" class="form-control" id="rcode2" placeholder="Enter Code">
      </div>
    </div>
	
    
    
      
      <div class="form-group">
      <label class="control-label col-sm-2"></span> </label>
      <div class="col-sm-3">          
          
           <input type="button" id="reg" name="Register" class="btn btn-success" style="width: 100%;" value="Register"/>
        
      </div>
    </div>
  </form>
</div>
		
<!---------------------------end------------>

</div>
<div class="modal-footer">
  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
</div>
</div>

</div>
</div>

</div>

<script>
  function signup()
  {
   
    $("#signup_model").modal();

  }
</script>

<?Php


?>