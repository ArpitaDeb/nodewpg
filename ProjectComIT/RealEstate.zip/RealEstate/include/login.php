<style>
    .modal-header, h4, .close {
        background-color: #FF4D4D;
        color:white !important;
        text-align: center;
        font-size: 30px;
    }

</style>
<div class="container">

    <!-- Modal -->
    <div class="modal fade" id="login_model" role="dialog">
        <div class="modal-dialog modal-sm">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Login</h4>
                </div>
                <div class="modal-body">
                    <!-------- login--------------------->
                    <div class="container">
                        <br />
                        <form class="form-horizontal" role="form" action="" >
                            <div id="message_login"> </div>
                            <div class="form-group" >
                                <label class="control-label col-sm-2">Email:</label>
                                <div class="col-sm-3">          
                                    <input type="email" class="form-control" id="lemail" placeholder="Enter Email">
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="control-label col-sm-2">Password:</label>
                                <div class="col-sm-3">          
                                    <input type="password" class="form-control" id="lpassword" placeholder="Enter password">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-sm-2"></span> </label>
                                <div class="col-sm-3">          

                                    <input type="button" id="log" name="login" class="btn btn-success" style="width: 100%;" value="Login"/>
                                </div>
                            </div>


                            <br>
                            <div class="form-group">
                                <div class="col-sm-5" align="right">     
                                    <a href="#"  onClick="create_new();" style=" text-decoration: none;" class="btn btn-info btn-xs">Create New Account</a>
                                    
                                    <br>
                                    <a href="#"  onClick="forgot_password();"  class="btn btn-primary btn-xs" style=" text-decoration: none;">Forgot password?</a>&nbsp;
                                </div>
                            </div>
                        </form>
                    </div>

                    <!---------------------------end------------>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

</div>

<script>
    function login()
    {

        $("#login_model").modal();

    }
    function create_new()
    {
        $("#login_model").modal("hide");
        $("#signup_model").modal();

    }
</script>