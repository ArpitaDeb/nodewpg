<script type="text/javascript">
  function RestrictSpace() {
    if (event.keyCode == 32) {
      return false;
    }
  }

  function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if ((charCode < 48 || charCode > 57))
     return false;

   return true;
 }

 $(function() {$("#reg").click(function() {

  var username = /^[0-9a-zA-Z]+$/;  
  var emailRegEx = /^[A-Z0-9._]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
  var password = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;

  var rname = $("#rname").val();
  var remail = $("#remail").val();
  var rpassword1 = $("#rpassword1").val();
  var rpassword2 = $("#rpassword2").val();
  var rmobil = $("#rmobil").val();
  var rselect_user = $("#rselect_user").val();
  var rcode1 = $("#rcode1").val();
  var rcode2 = $("#rcode2").val();

  if(rname==''){
//alert("Enter name");
showToastblack.show('Enter User Name!',2000)
$("#rname").focus();
}

else if($("#rname").val().search(username) == -1) {
         // alert("user name must be number and alphabetes"); 
         showToastblack.show('user name must be number and alphabetes',2000)   
         $("#rname").focus();
       }
       

       else if(remail==''){
//alert("Enter email");
showToastblack.show('Enter email',2000)
$("#remail").focus();   
}
else if($("#remail").val().search(emailRegEx) == -1) {
         // alert("Email id is not valied");
         showToastblack.show('Email id is not valied',2000)
         $("#remail").focus();
       }
       
       
       else if(rpassword1==''){
  //alert("Enter password");
  showToastblack.show('Enter password',2000)
  $("#rpassword1").focus();
}
else if($("#rpassword1").val().search(password) == -1) {
         // alert("password is not valied at least one number, one lowercase and one uppercase letter at least six characters");
         showToastblack.show('password is not valid at least one number, one lowercase and one uppercase letter at least six characters',4000)
         $("#rpassword1").focus();
       }
       
       else if(rpassword2==''){
  //alert("Enter confirm  password");
  showToastblack.show('Enter confirm  password',2000)
  $("#rpassword2").focus();
}
else if($("#rpassword2").val().search(password) == -1) {
          //alert("confirm password is not valied at least one number, one lowercase and one uppercase letter at least six characters");
          showToastblack.show('confirm password is not valied at least one number, one lowercase and one uppercase letter at least six characters',10000)
          $("#rpassword2").focus();
        }
        
        else if(rpassword1!==rpassword2){
  //alert("password and confirm password is not match");
  showToastblack.show('password and confirm password is not match',2000)
  $("#rpassword1").focus();
}

else if(rmobil==""){
  //alert("enter mobil number");
  showToastblack.show('enter mobil number',2000)
  $("#rmobil").focus();
}

else if(isNaN(rmobil)){
  showToastblack.show('Enter the valid Mobile Number(Like : 95661 37117)',2000)
  $("#rmobil").focus();
//alert("Enter the valid Mobile Number(Like : 9566137117)");
}


else if(rmobil.length<10 || rmobil.length>10 ){
//alert("enter mobil must be 10 digit");
showToastblack.show('enter mobil must be 10 digit',2000)
$("#rmobil").focus();
}

else if(rselect_user=="0"){
//alert("Enter name");
showToastblack.show('Please Select uset type!',2000)
$("#rselect_user").focus();
}  

else if(rcode2==""){
  //alert("enter mobil number");
  showToastblack.show('enter Code',2000)
  $("#rcode2").focus();
}

else if(rcode1!=rcode2){
  //alert("enter mobil number");
  showToastblack.show('code is not match',2000)
  $("#rcode2").focus();
}

else
{
 document.getElementById("reg").value="Registering......";
 var dataString = 'rname='+ rname +'&remail='+ remail +'&rpassword1='+ rpassword1 +'&rmobil='+ rmobil +'&rselect_user='+ rselect_user;
 $.ajax({
  type: "POST",
  url: "request_signup.php",
  data: dataString,
  cache: true,
  success: function(html)
  {
    $("#message").after(html);
    document.getElementById("reg").value="Register";
    document.getElementById('rname').value='';
    document.getElementById('remail').value='';
    document.getElementById('rpassword1').value='';
    document.getElementById('rpassword2').value='';
    document.getElementById('rmobil').value='';
    document.getElementById('rselect_user').value='';
    document.getElementById('rcode2').value='';
//$("#rname").val()='';
//$("#email").focus();
}  
});
}
return false;
});
});

</script>


<script type="text/javascript">

  $(function() {$("#log").click(function() {
   
    var emailRegEx1 = /^[A-Z0-9._]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
    var lemail = $("#lemail").val();
    var lpassword = $("#lpassword").val();

    if(lemail==''){
//alert("Enter email");
showToastblack.show('Enter email',2000)
$("#lemail").focus();   
}

else if($("#lemail").val().search(emailRegEx1) == -1) {
         // alert("Email id is not valied");
         showToastblack.show('Email id is not valied',2000)
         $("#lemail").focus();
       }
       
       
       else if(lpassword==''){
  //alert("Enter password");
  showToastblack.show('Enter password',2000)
  $("#lpassword").focus();
}

else
{
  document.getElementById("log").value="login....";
  var dataString = 'lemail='+ lemail +'&lpassword='+lpassword;
  $.ajax({
    type: "POST",
    url: "request_login.php",
    data: dataString,
    cache: true,
    success: function(html)
    {
      $("#message_login").after(html);
      document.getElementById("log").value="login";
      document.getElementById('lemail').value='';
      document.getElementById('lpassword').value='';
//$("#email").focus();
}  
});
}
return false;
});
});

</script>

<script type="text/javascript">

  $(function() {$("#forgot").click(function() {
   
    var emailRegEx1 = /^[A-Z0-9._]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;

    var femail = $("#femail").val();
    if(femail==''){
//alert("Enter email");
showToastblack.show('Enter email',2000)
$("#femail").focus();   
}

else if($("#femail").val().search(emailRegEx1) == -1) {
         // alert("Email id is not valied");
         showToastblack.show('Email id is not valied',2000)
         $("#femail").focus();
       }
       
       
       else
       {
        document.getElementById("forgot").value="Sending.....";
        var dataString = 'femail='+ femail;
        $.ajax({
          type: "POST",
          url: "responce_forgot.php",
          data: dataString,
          cache: true,
          success: function(html)
          {
            $("#message_f").after(html);
            document.getElementById("forgot").value="Send";
            document.getElementById('femail').value='';
//$("#email").focus();
}  
});
      }
      return false;
    });
});

</script>