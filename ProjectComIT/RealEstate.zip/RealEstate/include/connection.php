<?php
error_reporting(0);
 session_start();
$mysql_host = "localhost";
$mysql_database = "real_estate";
$mysql_user = "root";
$mysql_password = "";
mysql_connect($mysql_host,$mysql_user,$mysql_password);
mysql_select_db($mysql_database);

?>