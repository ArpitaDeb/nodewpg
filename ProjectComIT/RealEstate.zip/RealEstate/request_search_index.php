 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
 <script type="text/javascript" src="include/dist/script/showToast.js"></script>

 <?php include_once("include/connection.php");	?>
 <table width="58%" align="center" class="table" style="width:100%;" >

  <?Php


  $category =$_POST['category'];
  $type =$_POST['type'];
  $budget =$_POST['budget'];
  $city =$_POST['city'];


  if($category!='')
  {
    $a=0;

    $q = mysql_query("select properties.*,cities.city_name,states.state_name,countries.country_name,category.Category_type from properties 
      join cities on properties.city = cities.city_id 
      join states on cities.state_id = states.state_id 
      join countries on  states.country_id  = countries.country_id
      join category on  properties.Category_id = category.Category_id 
      where properties.Category_id='$category' AND properties.action ='$type' AND properties.price <= $budget AND  properties.city='$city' AND properties.status='1' ");

    $row=mysql_num_rows($q);


  }
  else
  {
   $a=0;
   // sleep(1);
   $q = mysql_query("select properties.*,cities.city_name,states.state_name,countries.country_name,category.Category_type from properties 
    join cities on properties.city = cities.city_id 
    join states on cities.state_id = states.state_id 
    join countries on  states.country_id  = countries.country_id
    join category on  properties.Category_id = category.Category_id  where  properties.status='1'
    ORDER BY p_id DESC LIMIT 5 ");
               //$q = mysql_query("SELECT * FROM `properties`");
   $row=mysql_num_rows($q);

 }

 while($arr=mysql_fetch_object($q))
 {
   ?>

   <tr >

     <td colspan="2"> <div style="font-size: 15pt;color: #0052cc;" ><?php echo $arr->address; ?></div></td>
   </tr>


   <tr>

     <td width="20pt;" align="center">


       <?Php 
       if($arr->pro_image=="")
       {
         ?>
         <img src="images/images.png"width="170" height="170" draggable="false"  class="img-rounded"/> 
         <?php
       }
       else 
        {
          ?>
         <img src="<?php echo $arr->pro_image;?>" width="170" height="170" draggable="false"  class="img-rounded"/> 

         <?php
       }
       ?>


     </td>         



     <td width="62%" align="left">

      <br>
      <i class="fa fa-inr" aria-hidden="true"></i>  <?php echo $arr->price." - ".$arr->Bedrooms."BHK ,".$arr->city_name; ?><br>



      <i class="fa fa-star" aria-hidden="true"></i> <?php echo $arr->action; ?><br>

      <i class="fa fa-area-chart" aria-hidden="true"></i> <?php echo $arr->area." sqft"; ?><br>
      <i class="fa fa-globe" aria-hidden="true"></i> <?php echo $arr->country_name.", ".$arr->state_name; ?><br>
      <i class="fa fa-phone" aria-hidden="true"></i> <?php echo $arr->mobile; ?><br>
      <div style="text-align: right;"><a href="more_detail.php?p=<?php echo $arr->p_id; ?>&&u=<?php echo $arr->u_id; ?>"  target="_blank" class="btn btn-info btn-sm"><i class="fa fa-th-large"></i> More Details </a></div>
      <br>

    </td>
  </tr>

  <?Php
}
?>



<?php
if($row==0)
{
 echo '<b style="color: #423939;font-size: 11pt;text-align: center;">'."no add any properties".'</b>';
}
?>







</table>

