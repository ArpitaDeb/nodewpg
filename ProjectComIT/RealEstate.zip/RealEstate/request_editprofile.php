 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  
 <?php include_once("include/connection.php");
 
 
   
  $rname=$_POST['rname'];
 $rmobil=$_POST['rmobil'];
 $e=$_SESSION['u_id'];
 

  if($rname!="")
  {
      
                          $up=("update user set name='$rname',mobile='$rmobil' where u_id='$e'");	
                           $u=mysql_query($up);	
                           if($u)
                           {
                          
                               ?>
                                <script>
                                
                                  location.href='myprofile.php';
                                </script>
                              
                   <?php
                           }
                        else
                         {
                         echo "not updatd";
                            }
                           
                              
                          
           
  }   
 ?>

  






