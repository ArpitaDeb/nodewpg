 <?php include("include/connection.php");?>

<?php
if(!isset($_SESSION['u_id']))
{
header("location:index.php");
}
?>


  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" align="center">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">data update</h4>
        </div>
        <div class="modal-body">
 <form class="form-horizontal" role="form" action="" id="uploadForm" method="post">
     <input type="hidden"  id="pid"  name="pid" value="" placeholder="Enter id"/>
     <input type="hidden"  id="path" name="path" value="" placeholder="Enter id"/>
     <input type="hidden"  id="url"  name="url" value="" placeholder="Enter id"/>
	
            
          
    <input type="file" class="form-control" name="profile" id="profile" onchange="ValidateSingleInput(this);">
     
  
	
	<br><br>
        <input type="submit" name="update" value="update"  id="submit"  class="btn btn-primary"/>
 </form>
         <div id="m"></div>
  
   
        </div>
           <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div> 
  
  
<!-----------promodel----------->

<!-- Modal -->
  <div class="modal fade" id="myModalpro" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" align="center">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">data update</h4>
        </div>
        <div class="modal-body">
 <form class="form-horizontal" role="form" action="" id="uploadFormpro" method="post">
     <input type="hidden"  id="pid1"  name="pid1" value="" />
    
   
            
          
          <input type="file" class="form-control" name="profile1" id="profile1" onchange="ValidateSingleInput(this);">
     
  
	
	<br><br>
        <input type="submit" name="update" value="update"  id="submit1"  class="btn btn-primary"/>
 </form>
         <div id="m1"></div>
  
   
        </div>
           <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div> 


 <!DOCTYPE HTML>
 <html class="no-js">
 <head>
<!-- Basic Page Needs
  ================================================== -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Real Estate</title>
  <link rel="icon" type="image/png" href="favicon.png">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="format-detection" content="telephone=no">
<!-- CSS
  ================================================== -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
  <!-- Color Style -->
  <link class="alt" href="colors/color1.css" rel="stylesheet" type="text/css">
  <link href="style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
<!-- SCRIPTS
  ================================================== -->
  <script src="js/modernizr.js"></script><!-- Modernizr -->
  
</head>
<body class="home">

  <div class="body">
    <!-- Start Site Header -->
    <!-- Start Site Header -->
    <header class="site-header">

      <?php include("top_header.php");?>
      
      <?Php include("middle_header.php");?>

      <?php include("menu.php");?>
         
    </header>

    <!-- Start Content -->
    <div class="main" role="main">
      <div id="content" class="content full">
        <div class="featured-blocks">
 
              
              <div class="container">


     


                  
                  
             <?php
if(isset($_REQUEST['imgdel']))
{
                $img_id=$_REQUEST['imgdel'];
         
              
                 $se=mysql_query("SELECT * FROM `photo` WHERE photo_id = '$img_id'");
                  $fet=mysql_fetch_array($se);
                   unlink($fet['path']);
                 
                     $del=mysql_query("DELETE FROM photo WHERE photo_id = '$img_id'");
                    
                     if($del)
                     {
                      ?>
                   
                  <script>
                  alert('deleted sucessfully');
                  </script>
                     <?php
                         
                     }
?>
                     <script>
               location.href = 'property_image_info.php?pp=<?php echo $_REQUEST['pp']; ?>';
                  </script>
                  <?php
 
    
}
  ?>     
       
                  
                  
                  
<?Php
  
  $u_id=$_SESSION['u_id'];
  $pp=$_REQUEST['pp'];


        
if(isset($_REQUEST['imgdelpro']))
{
          
         
              
              $se1= mysql_query("SELECT * FROM `properties` WHERE p_id='$pp' AND u_id='$u_id'");
                  $fet=mysql_fetch_array($se1);
                  unlink($fet['pro_image']);
              
                $del=mysql_query("UPDATE `properties` SET `pro_image`=''  WHERE p_id='$pp' AND u_id='$u_id'");
                    
                     if($del)
                     {
                      ?>
                   
                  <script>
                  alert('deleted sucessfully');
                  </script>
                     <?php
                         
                     }
?>
                     <script>
               location.href = 'property_image_info.php?pp=<?php echo $_REQUEST['pp']; ?>';
                  </script>
                  <?php
 
    
}
  
       




           //profile image
              
  
                $pro = mysql_query("SELECT * FROM `properties` WHERE p_id='$pp' AND u_id='$u_id'");
               //$q = mysql_query("SELECT * FROM `properties`");
			while($ap=mysql_fetch_object($pro))
			{
                        
			?>
                  <div style="font-size: 16pt;"> profile images</div>
                <div class="col-sm-4" align="center">  
                    <br>
                    <?php
                      if($ap->pro_image=="")
                    {
                     ?>
                    <img src="images/images.png" width="200" height="100" draggable="false"/> 
                     <?php
                    }
                    else 
                    { 
                      ?>
             <img src="<?php echo $ap->pro_image; ?>" width="400" height="170" draggable="false" class="img-thumbnail"/> 
     
                    <?php 
                        }
                     ?>
                     
                    </div>

                 
   <div class="col-sm-8"> 
          <br>
          <br>
                 <a href="#" class="btn btn-warning btn-sm"  onClick="editpro(<?php echo $ap->p_id;?>,'<?php echo $ap->pro_image;?>',<?php echo $_REQUEST['pp'];?>);"> <b class="fa fa-edit w3-large" style="font-size: 11pt;"></b> update</a>
          <?php 
             if($ap->pro_image!="")
               {
               ?>
 <a href="property_image_info.php?imgdelpro=<?php echo $ap->p_id;?>&&pp=<?php echo $pp?>"  class="btn btn-danger btn-sm" OnClick="return confirm('do you want remove this image?');"> <b class="fa fa-trash w3-large" style="font-size: 11pt;"></b> Delete </a>
                <?php
              }
                 ?>
                       <br> <br><br>
                       
         </div>
                  <hr style="background-color:#999966;">
                        <?Php
                        }
                        ?>
    
  
  
  
  
  
  <div style="font-size: 16pt;">Other images</div>
  <?php
    $ac=0;

               $q = mysql_query("SELECT * FROM `photo` WHERE p_id='$pp' AND u_id='$u_id'");
               //$q = mysql_query("SELECT * FROM `properties`");
			while($arr=mysql_fetch_object($q))
			{
                              $ac++;
			?>
                
                <div class="col-sm-4" align="center">  
                    <br>
                    <?php echo $ac; ?>
                     <img src="<?php echo $arr->path; ?>" width="400" height="170" draggable="false" class="img-thumbnail"/> 
                    </div>

                 
   <div class="col-sm-8"> 
          <br>
          <br>
                 <a href="#" class="btn btn-warning btn-sm"  onClick="edit(<?php echo $arr->photo_id;?>,'<?php echo $arr->path;?>',<?php echo $_REQUEST['pp'];?>);"> <b class="fa fa-edit w3-large" style="font-size: 11pt;"></b> update</a>
                 
 <a href="property_image_info.php?imgdel=<?php echo $arr->photo_id;?>&&pp=<?php echo $pp?>"  class="btn btn-danger btn-sm" OnClick="return confirm('do you want remove this image?');"> <b class="fa fa-trash w3-large" style="font-size: 11pt;"></b> Delete </a>
                       <br> <br><br>
                       
         </div>
                  <hr style="background-color:#999966;">
                        <?Php
                        }
                        ?>
     <?php
      if($ac==0)
                   {
          ?>
                  <br>
                  <?php
                    echo "no add any other images";
                   }


?>



 
    
        
                <!---end                                                                      contant------->
                
          </div>
        </div>
              
             <?php
if(isset($_POST['more']))
{
    if($_FILES['file']['name']!="")
    {
       $p_id=$_REQUEST['pp'];

                        $file_name=$_FILES['file']['name'];
                        $ex=explode(".",$file_name);
                        $type=$ex[1];
                        $path="property_image/"."865".time().".".$type;
                        move_uploaded_file($_FILES['file']['tmp_name'],$path);


                    $ss=mysql_query("INSERT INTO `photo`(`p_id`, `path`, `u_id`) VALUES ($p_id,'$path',$u_id)");
             
                    
                     if($ss)
                     {
                      ?>
                    <script>
                  alert('image Add sucessfully');
                  </script>
                  
                     <?php

                         
                     }

                     ?>
                  <script>
               location.href = 'property_image_info.php?pp=<?php echo $_REQUEST['pp']; ?>';
                  </script>
                     <?php

                
                     
 }
    
}
  ?>     
       


         <div class="padding-tb45 bottom-blocks">
          <div class="container">
              <?php
  if($ac<7)
  {
  ?>

          Add More Images
          <form class="form-horizontal" role="form" action="" method="post" enctype="multipart/form-data">

            
      <div class="col-sm-4" >  
    <input type="file" class="form-control" name="file" onchange="ValidateSingleInput(this);">
     </div>
  
  
  <div class="col-sm-2" >  
        <input type="submit" name="more" value="more"  id="submit"  class="btn btn-primary"/>
         </div>


    <?php
}
    ?>
 </form>

  you can Maximuu 7 Image.

          </div>
        </div>

        <footer class="site-footer-bottom">
         <?Php include("footer.php");?>
       </footer>
       <!-- End Site Footer -->
       <a id="back-to-top"><i class="fa fa-angle-double-up"></i></a>
     </div>
     <script src="js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call --> 
     <script src="plugins/flexslider/js/jquery.flexslider.js"></script> <!-- FlexSlider --> 
     <script src="js/helper-plugins.js"></script> <!-- Plugins --> 
     <script src="js/bootstrap.js"></script> <!-- UI --> 
     <script src="js/waypoints.js"></script> <!-- Waypoints --> 
     <script src="js/init.js"></script> <!-- All Scripts -->
     <!--[if lte IE 9]><script src="js/script_ie.js"></script><![endif]--> 


   </body>

   </html>
   

   <script>
function edit(potoid,path,url)
        {
document.getElementById('pid').value=potoid;
document.getElementById('path').value=path;
document.getElementById('url').value=url;
		
     // document.getElementById(no).value=id;
         $("#myModal").modal("show");
       }
       
       
       function editpro(pid)
        {

document.getElementById('pid1').value=pid;

     // document.getElementById(no).value=id;
         $("#myModalpro").modal("show");
       }
	   
	   
	 
         
          var _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".gif", ".png"];    
function ValidateSingleInput(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid, allowed extensions are: " + _validFileExtensions.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}



$(document).ready(function (e) {
	$("#uploadForm").on('submit',(function(e) {
            var pid = $("#pid").val();
           
            var file = $("#profile").val();
        
         
           
            
          
           if(file==''){
               showToastblack.show('select image.',2000)
                return false;
            }
            
           
            else
            {
                   

		e.preventDefault();
                 document.getElementById("submit").value="updating.....";
		$.ajax({
                        url: "request_update_image.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
                        cache: false,
			processData:false,
                        success: function(html)
                            {
                            $("#m").after(html);
                            document.getElementById("submit").value="update";
                          
         
                            }  

		       
                        });
                        
        }
	}));
});


$(document).ready(function (e) {
	$("#uploadFormpro").on('submit',(function(e) {
            var pid = $("#pid1").val();
           
            var file = $("#profile1").val();

           if(file==''){
               showToastblack.show('select image.',2000)
                return false;
            }
            
           
            else
            {
                   
		e.preventDefault();
                 document.getElementById("submit1").value="updating.....";
		$.ajax({
                        url: "request_update_image.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
                        cache: false,
			processData:false,
                        success: function(html)
                            {
                            $("#m1").after(html);
                            document.getElementById("submit1").value="update";
                          
         
                            }  

		       
                        });
                        
        }
	}));
});
</script>
</script>