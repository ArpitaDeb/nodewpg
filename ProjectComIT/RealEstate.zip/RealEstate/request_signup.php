 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  
 <?php include_once("include/connection.php");
 
 
   
 $rname=$_POST['rname'];
 $remail=$_POST['remail'];
 $rpassword=$_POST['rpassword1'];
 $rpassword1= base64_encode($rpassword);
 $rmobil=$_POST['rmobil'];
 $rselect_user=$_POST['rselect_user'];
 $verification_code=md5(uniqid(rand())); 
 // $q = mysql_query("insert into user(name,email,password,mobile,user_type,verification_code)"
        //. " values('$rname','$remail','$rpassword1',$rmobil,$rselect_user,'$verification_code')");

  if($rname!="")
  {
     // sleep(2);
       $q=("select * from user where email='$remail'");
        $x=mysql_query($q);
        $r=mysql_num_rows($x);
        $f=mysql_fetch_array($x);

            if($r==1 && $f['verification_status']==0)
                {	
                    $to=$remail;           
                    $subject="Your confirmation link here";							
                    $header="from: Propertys <darshantank2012@gmail.com>";					
                    $message="Your Comfirmation link \r\n";
                    $message.="Click on this link to activate your account \r\n";
                    $message.="http://www.propertysdekho.xyz//email_confirm.php?passkey=$verification_code";
                    $sent = mail($to,$subject,$message,$header);
                        if($sent)
                            {
                          $up=("update user set name='$rname',password='$rpassword1',mobile='$rmobil',user_type='$rselect_user',verification_code='$verification_code' where email='$remail'");	
                           $u=mysql_query($up);	
                           
                               if($u)
                                  {
                                   ?>
                                 <script>showToastblack.show('Resend email varification link.',2000) </script>
                                   <?php
                                   }
                                    else
                                    {
                                     ?>
                                  <script>showToastblack.show('Unable to create account',2000) </script>
                                     <?php
                                    }
                                       
                            }
                           else
                           {
                           ?>
                           <script>showToastblack.show('Unable to send Confirmation link to your e-mail address.',2000) </script>
                           <?php
                           }
	
                }
                
                 else if($r==1 && $f['verification_status']==1)
                  {
                     
                            ?>
                           <script>showToastblack.show('your account is already created.',2000) </script>
                           <?php
                   }
                   else if($r!==1)
                     {
                        
                     $to=$remail;           
                    $subject="Your confirmation link here";							
                    $header="from: Propertys <darshantank2012@gmail.com>";					
                    $message="Your Comfirmation link \r\n";
                    $message.="Click on this link to activate your account \r\n";
                    $message.="http://www.propertysdekho.xyz//email_confirm.php?passkey=$verification_code";
                    $sent = mail($to,$subject,$message,$header);
                        if($sent)
                            {
                             $q = mysql_query("insert into user(name,email,password,mobile,user_type,verification_code)"
                            . " values('$rname','$remail','$rpassword1',$rmobil,$rselect_user,'$verification_code')");
                                 
                                if($q)
                                   {
                                   ?>
                                 <script>showToastblack.show('Email varification link sended in your e-mail account and your account is sucessfully created.',10000) </script>
                                   <?php
                                   }
                                    else
                                    {
                                     ?>
                                         <script>showToastblack.show('Unable send Confirmation link to your e-mail address.',2000) </script>
                                    <?php
                                     }
                             
                               }
                               else
                                    {
                                     ?>
                                         <script>showToastblack.show('Unable send Confirmation link to your e-mail address.',2000) </script>
                                    <?php
                                     }
                     }
                    else 
                        {
                                        ?>
                                         <script>showToastblack.show('Unable to create  account',2000) </script>
                                    <?php
                        }
           
  }   
 ?>

  






