 <?php include("include/connection.php");?>

 <?php
 if(!isset($_SESSION['u_id']))
 {
  header("location:index.php");
}
?>
<!DOCTYPE HTML>
<html class="no-js">
<head>
<!-- Basic Page Needs
  ================================================== -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Real Estate</title>
  <link rel="icon" type="image/png" href="favicon.png">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="format-detection" content="telephone=no">
<!-- CSS
  ================================================== -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
  <!-- Color Style -->
  <link class="alt" href="colors/color1.css" rel="stylesheet" type="text/css">
  <link href="style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
<!-- SCRIPTS
  ================================================== -->
  <script src="js/modernizr.js"></script><!-- Modernizr -->
  
</head>
<body class="home">

  <div class="body">
    <!-- Start Site Header -->
    <!-- Start Site Header -->
    <header class="site-header">

      <?php include("top_header.php");?>
      
      <?Php include("middle_header.php");?>

      <?php include("menu.php");?>

    </header>

    <!-- Start Content -->
    <div class="main" role="main">
      <div id="content" class="content full">
        <div class="featured-blocks">
          <div class="">
              <!---maincontant contant                                                             ------->
              <div class="container">

                <!-- Modal -->
                <div role="dialog">
                  <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                      <div class="modal-header">

                        <h4 class="modal-title"><i class="fa fa-plus-square"></i> &ensp;Add Property Request</h4>
                      </div>
                      <div class="modal-body">
		<!-------- login--------------------->
		<div class="container">
<br />


<form class="form-horizontal" role="form" action="" id="uploadForm" method="post">
   <div id="m"> </div>

  
    <div class="form-group">
      <label class="control-label col-sm-2">Category:</label>
      <div class="col-sm-3">          
          <select  class="form-control" id="categoty" name="categoty">
            <option selectd value="0">Select Category</option>
          <?php
          
	   $sel="select * from category ";
	   $ex=mysql_query($sel);
	   while($arr=mysql_fetch_array($ex))
	   {
	   ?>
            <option value="<?php echo $arr['Category_id'] ?>">
			
			<?php echo $arr['Category_type']; ?></option>
       <?php
	   }
	   ?>
      </select>
      </div>
    </div>
   
   <div class="form-group">
  (in Sqft)
      <label class="control-label col-sm-2">Area Of Propertys</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" id="area" onkeypress="return isfNumberKey(event)" name="area" placeholder="Enter Area">
      </div>
    </div>
   
   <div class="form-group">
      <label class="control-label col-sm-2">Price:</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" id="price" name="price" placeholder="Enter Price" onkeypress="return isfNumberKey(event)">
      </div>
    </div>
   
   <div class="form-group">
      <label class="control-label col-sm-2">Bedrooms:</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" id="bedrooms" onkeypress="return isNumberKey(event)" name="bedrooms" placeholder="Enter Bedrooms">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2">Action:</label>
      <div class="col-sm-3">          
          <select  class="form-control" id="action" name="action">
            <option selectd value="0">Select Action</option>
            <option value="Sell">Sell</option>
            <option value="Rent">Rent</option>
      </select>
          
      </div>
    </div>
   
   
   

   <div class="form-group">
      <label class="control-label col-sm-2">Desription:</label>
      <div class="col-sm-3">          
      
          <textarea class="form-control" rows="5" id="address" name="address"></textarea>
      </div>
    </div>
   
   <div class="form-group">
      <label class="control-label col-sm-2">City:</label>
      <div class="col-sm-3">          
          <select  class="form-control" id="fcity" name="fcity">
            <option selectd value="0">Select City</option>
       <?php
	   $ci="select * from cities ORDER BY city_name ASC";
	   $e1=mysql_query($ci);
	   while($arr1=mysql_fetch_array($e1))
	   {
	   ?>
            <option value="<?php echo $arr1['city_id'] ?>">
			
			<?php echo $arr1['city_name']; ?></option>
       <?php
	   }
	   ?>
      </select>
          
      </div>
    </div>
   
    <div class="form-group">
      <label class="control-label col-sm-2">Mobile No:</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" id="mobile" onkeypress="return isNumberKey(event)" name="mobile" placeholder="Enter Mobile No">
      </div>
    </div>
   
  
   
  
	
   
      <div class="form-group">
      <label class="control-label col-sm-2"></span></label>
      <div class="col-sm-3">   
          
          <input type="submit" id="submit" name="submit" class="btn btn-success" style="width: 100%;" value="submit"/>
       
      </div>
    </div>
   
   
      
     
  </form>
</div>
		
<!---------------------------end------------>

</div>

</div>

</div>
</div>
<!---- >
</div>
                <!---end                                                                      contant------->
                
          </div>
        </div>
       


         <div class="padding-tb45 bottom-blocks">
          <div class="container">

          </div>
        </div>

       
        <!-- End Site Footer -->
        <a id="back-to-top"><i class="fa fa-angle-double-up"></i></a>
      </div>
    </div>
    <footer class="site-footer-bottom">
     <?Php include("footer.php");?>
   </footer>
   <script src="js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call --> 
   <script src="plugins/flexslider/js/jquery.flexslider.js"></script> <!-- FlexSlider --> 
   <script src="js/helper-plugins.js"></script> <!-- Plugins --> 
   <script src="js/bootstrap.js"></script> <!-- UI --> 
   <script src="js/waypoints.js"></script> <!-- Waypoints --> 
   <script src="js/init.js"></script> <!-- All Scripts -->
   <!--[if lte IE 9]><script src="js/script_ie.js"></script><![endif]--> 


 </body>

 </html>

 <script type="text/javascript">



  function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if ((charCode < 48 || charCode > 57))
     return false;

   return true;
 }

 function isfNumberKey(evt)
 {
  var charCode = (evt.which) ? evt.which : event.keyCode;
  if (charCode != 46 && charCode > 31 
    && (charCode < 48 || charCode > 57))
   return false;

 return true;
}




$(document).ready(function (e) {
	$("#uploadForm").on('submit',(function(e) {
    var categoty = $("#categoty").val();
    var area = $("#area").val();
    var price = $("#price").val();
    var bedrooms = $("#bedrooms").val();
     var action = $("#action").val();
    var address = $("#address").val();
    var fcity = $("#fcity").val();
    var mobile = $("#mobile").val();


    if(categoty=='0'){
     showToastblack.show('Select category.',2000)
       $("#categoty").focus();
     return false;
   }

   else if(area==''){
     showToastblack.show('Enter area.',2000)
      $("#area").focus();
     return false;
   }

   else if(price==''){
     showToastblack.show('Enter price.',2000)
    $("#price").focus();
     return false;
   }

   else if(bedrooms==''){
     showToastblack.show('Enter bedrooms.',2000)
     $("#bedrooms").focus();
     return false;
   }

   else if(action=='0'){
 showToastblack.show('select action.',2000)
     $("#action").focus();
 return false;
}
 
   else if(address==''){
     showToastblack.show('enter address.',2000)
      $("#address").focus();
     return false;
   }
   else if(fcity=='0'){
     showToastblack.show('select city.',2000)
         $("#fcity").focus();
     return false;
   }
   else if(mobile==''){
     showToastblack.show('enter mobil no.',2000)
       $("#mobile").focus();
     return false;
   }

   else if(mobile.length<10 || mobile.length>10 ){
//alert("enter mobil must be 10 digit");
showToastblack.show('enter mobil must be 10 digit',2000)
    $("#mobile").focus();
return false;
   }


else
{


  e.preventDefault();
  document.getElementById("submit").value="submiting.....";
  $.ajax({
    url: "request_request.php",
    type: "POST",
    data:  new FormData(this),
    contentType: false,
    cache: false,
    processData:false,
    success: function(html)
    {
      $("#m").after(html);
      document.getElementById("submit").value="submit";
      document.getElementById("categoty").value='0';
      document.getElementById('area').value='';
      document.getElementById('price').value='';
      document.getElementById('bedrooms').value='';
      document.getElementById('address').value='';
      document.getElementById('fcity').value='0';
      document.getElementById('mobile').value='';
      document.getElementById('action').value='0';



    }  


  });

}
}));
});
</script>
