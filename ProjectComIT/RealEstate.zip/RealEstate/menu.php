  <div class="main-menu-wrapper">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <nav class="navigation">
                <ul class="sf-menu">
                 <?php
                 if(!isset($_SESSION['u_id']))
		{
		?>
                  <li><a href="index.php">Home</a></li>
                   <li><a href="#" onClick="login();">Login</a></li>
                    <li><a href="#" onClick="signup();">Register</a></li>
                     <li><a href="feedback.php">Feedback</a></li>
                <?php
		}
		?>



                  
                 <?php
                 if($_SESSION['as']=='1')
		{
		?>
                  <li><a href="home_agent.php">Home</a></li>

                   <li><a href="javascript:;">Selling</a>
                    <ul class="dropdown">         
                      <li><a href="add_properties.php">Add property</a></li>
                      <li><a href="my_property_info.php">My property info</a></li>
                    </ul>
                  </li>
                  </li>

                    <li><a href="feedback.php">Feedback</a></li>

                    <li class="nav navbar-nav navbar-right"><a href=#><b class="fa fa-user" ></b> My Account <?php echo "(".$_SESSION['name'].")" ?></a>
                    <ul class="dropdown" > 
                         <li><a href="myprofile.php">My Frofile</a></li>
                         <li><a href="change_pass.php">Change Password</a></li>
                      <li><a href="logout.php">Logout</a></li>
                    </ul>
                  </li>
                  </li>

                <?php
		}
		?>


                 <?php
                 if($_SESSION['as']=='2')
    {
    ?>
                  <li><a href="home_customer.php">Home</a></li>
                      <li><a href="javascript:;">Request for property</a>
                    <ul class="dropdown">         
                      <li><a href="add_request.php">Add Request</a></li>
                      <li><a href="my_request_info.php">Request info</a></li>
                    </ul>
                  </li>
                  
                    <li><a href="feedback.php">Feedback</a></li>

                    <li class="nav navbar-nav navbar-right"><a href=#><b class="fa fa-user" ></b> My Account <?php echo "(".$_SESSION['name'].")" ?></a>
                    <ul class="dropdown" > 
                         <li><a href="myprofile.php">My Frofile</a></li>
                         <li><a href="change_pass.php">Change Password</a></li>
                      <li><a href="logout.php">Logout</a></li>
                    </ul>
                  </li>
                  </li>

                <?php
    }
    ?>
                  
                   
           
           
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
