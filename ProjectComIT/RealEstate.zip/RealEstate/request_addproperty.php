 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  
 <?php include_once("include/connection.php");
 
  $uid=$_SESSION['u_id'];    
 $categoty=$_POST['categoty'];
 $area=$_POST['area'];
  $price=$_POST['price'];
 
 $bedrooms=$_POST['bedrooms'];
 $floor=$_POST['floor'];
  $facing=$_POST['facing'];
  $address=$_POST['address'];

  $fcity=$_POST['fcity'];
 $mobile=$_POST['mobile'];
  $action=$_POST['action'];

 if($categoty!="")
 {                    
     //profile_image --------->
                 if($_FILES['profile']['name']!="")
                 {
                        $file_name=$_FILES['profile']['name'];
                        $ex=explode(".",$file_name);
                        $type=$ex[1];
                        $path="property_image/"."865".time().".".$type;
                        move_uploaded_file($_FILES['profile']['tmp_name'],$path);
                 }
                        //end_profile_image --------->
                        
  $q = mysql_query("insert into properties(u_id,Category_id,area,price,Bedrooms,floor,facing,address,city,mobile,action,pro_image)"
       . " values($uid,$categoty,$area,$price,$bedrooms,$floor,'$facing','$address',$fcity,$mobile,'$action','$path')");
  
               $u_idd = $_SESSION['u_id'];
               $max= mysql_query("SELECT MAX(p_id) FROM `properties` where u_id= '$u_idd'");
               $fet=mysql_fetch_array($max);
                $p_idmax=$fet['MAX(p_id)'];
               // sleep(2);
             
                        if($q)
                        {
                              $no=count($_FILES['file']['name']);
                            for($i=0;$i<$no;$i++)
                                 {
                                $name=$_FILES['file']['name'][$i];
                                 $ar=explode(".",$name);
                                $ext=$ar[1];
                                $path="property_image/".$r.time().".".$ext;
                                     if($ext!="")
                                         {
                                         $po = mysql_query("insert into photo(p_id,path,u_id) values($p_idmax,'$path',$uid)");
                                          move_uploaded_file($_FILES['file']['tmp_name'][$i],$path);
                                         }
 
                                            $r++;
                                 }
                             ?>
                             <script>showToastblack.show('sucessfully add propertys.',4000) </script>
                           <?php
                        }
                        else
                        {
                        echo "no";
                        }


     
 }
  
 ?>

  






