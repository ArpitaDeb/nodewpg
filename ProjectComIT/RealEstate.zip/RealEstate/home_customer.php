 <?php include("include/connection.php");?>

 <?php
 if(!isset($_SESSION['u_id']))
 {
  header("location:index.php");
}
?>
<!DOCTYPE HTML>
<html class="no-js">
<head>
<!-- Basic Page Needs
  ================================================== -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Real Estate</title>
  <link rel="icon" type="image/png" href="favicon.png">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="format-detection" content="telephone=no">
<!-- CSS
  ================================================== -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
  <!-- Color Style -->
  <link class="alt" href="colors/color1.css" rel="stylesheet" type="text/css">
  <link href="style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
<!-- SCRIPTS
  ================================================== -->
  <script src="js/modernizr.js"></script><!-- Modernizr -->
  
</head>
<body class="home">

  <div class="body">
    <!-- Start Site Header -->
    <!-- Start Site Header -->
    <header class="site-header">

      <?php include("top_header.php");?>
      
      <?Php include("middle_header.php");?>

      <?php include("menu.php");?>
     

      </header>

      <!-- Start Content -->
      <div class="main" role="main" >
        <div id="content" class="content full">
          <div class="featured-blocks">
            <div class="container" >


            
<div class="row">
    <div class="col-sm-8">
      <h1>Find Properties as your needs</h1>
    
    </div>
   </div>
              <!---maincontant------->
            

        <div class="site-search-module">
    <div class="container">

      <div class="">

        <form action="" method="post">
          <div class="form-group" >
            <div class="row">
              <div class="col-md-2" >
     
                <select name="category" id="category"  class="form-control input-lg selectpicker">
                   <option selectd value="0">Category</option>
          <?php
     $sel="select * from category ";
     $ex11=mysql_query($sel);
     while($ar11=mysql_fetch_array($ex11))
     {
     ?>
            <option value="<?php echo $ar11['Category_id']; ?>">
      
      <?php echo $ar11['Category_type']; ?></option>
       <?php
     }
     ?>
                  
                  
                </select>
                  
              </div>
        
              <div class="col-md-2">
                  <select name="type"  id ="type" class="form-control input-lg selectpicker" onchange="b();">
                  <option value="0" selected>Type</option>
                  <option value="Sell">Sell</option>
                  <option value="Rent">Rent</option>
                </select>
              </div>
                
               <div class="col-md-2" id="sell">
                   <select name="property_price" id="property_price" class="form-control input-lg selectpicker">
                   <option value="1000000" selected>less - 1000000</option>
                  <option value="2000000">less - 2000000</option>
                   <option value="3000000">less - 3000000</option>
                    <option value="4000000">less - 4000000</option>
                     <option value="5000000">less - 5000000</option>
                      <option value="6000000">less - 6000000</option>
                      <option value="6000000">less - 7000000</option>
                      <option value="6000000">less - 8000000</option>
                </select>
              </div>
                
               <div class="col-md-2" id="rent">
                   <select name="property_price" id="property_price" class="form-control input-lg selectpicker">
                  <option value="5000" selected>less - 5000</option>
                 <option value="10000">less - 10000</option>
                 <option value="15000">less - 15000</option>
                 <option value="20000">less - 20000</option>
                 <option value="25000">less - 25000</option>
                  <option value="30000">less - 30000</option>
                   <option value="35000">less - 35000</option>
                    <option value="40000">less - 40000</option>
                     <option value="45000">less - 45000</option>
                     <option value="50000">less - 50000</option>
                 
                  
                </select>
              </div>
                
               
     <div class="col-md-2">
     
                     <select name="property_city" id="property_city" class="form-control input-lg selectpicker">
                   <option selectd value="0">city</option>
          <?php
     $se="select * from cities ORDER BY city_name ASC ";
     $e=mysql_query($se);
     while($a=mysql_fetch_array($e))
     {
     ?>
            <option value="<?php echo $a['0']; ?>">
      
      <?php echo $a['1']; ?></option>
       <?php
     }
     ?>
                  
                  
                </select>
                  
              </div>
           
               
                
                <div class="col-md-2"> <button type="button" class="btn btn-primary btn-block btn-lg" onclick="search();"><i class="fa fa-search" ></i> Search</button> </div>

              
            </div>

              
          </div>
               
        </form>
      </div>
 <div id="txtHint" style=""> </div>
              <div id="loader"  align="center"> </div>

    </div>

  </div>
</div>
              
           
               
                <!---end  maincontant------->
          </div>
        </div>
       


         <div class="padding-tb45 bottom-blocks">
          <div class="container">

          </div>
        </div>

        
        <!-- End Site Footer -->
        <a id="back-to-top"><i class="fa fa-angle-double-up"></i></a>
      </div>
    </div>

    <script src="js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call --> 
    <script src="plugins/flexslider/js/jquery.flexslider.js"></script> <!-- FlexSlider --> 
    <script src="js/helper-plugins.js"></script> <!-- Plugins --> 
    <script src="js/bootstrap.js"></script> <!-- UI --> 
    <script src="js/waypoints.js"></script> <!-- Waypoints --> 
    <script src="js/init.js"></script> <!-- All Scripts -->
    <!--[if lte IE 9]><script src="js/script_ie.js"></script><![endif]--> 


  </body>

  </html>
  <script>

    function showtable()
    {

      if (window.XMLHttpRequest) 
      {
        xmlhttp=new XMLHttpRequest();
      }
      else

 { // code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function() 
{ 
  if (xmlhttp.readyState==4 && xmlhttp.status==200) 
  {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
  }

}

xmlhttp.open("POST","request_search_customer.php",true);
xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xmlhttp.send();


}

showtable();
</script>


<script>
  function search()
  {

   var category = document.getElementById('category').value;
   var type = document.getElementById('type').value;
   var budget = document.getElementById('property_price').value;
   var city = document.getElementById('property_city').value;


   if(category=='0')
   {
                    //alert("select category");
                    showToastblack.show('select category',2000)
                  }
                  else if(type=='0')
                  {
                   showToastblack.show('select type',2000)
                 }
                 
               
                 else if(city=='0')
                 {
                   showToastblack.show('select city',2000)
                 }
                 
                 
                 else
                 {

                   if (window.XMLHttpRequest) 
                   {
                    xmlhttp=new XMLHttpRequest();
                  }
                  else

                                 { // code for IE6, IE5
                                  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");

                                }
                                xmlhttp.onreadystatechange=function() 
                                {

                                  if (xmlhttp.readyState==4 && xmlhttp.status==200) 
                                  {
                                    document.getElementById("loader").innerHTML="";
                                    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
                                            //showtable()

                                          }

                                        }
                                        //show('status changing.......');
                                        document.getElementById("loader").innerHTML="<img src='images/loadingqqq.gif'/>";

                                        xmlhttp.open("POST","request_search_customer.php",true);
                                        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                                        xmlhttp.send("category="+category+"&type="+type+"&budget="+budget+"&city="+city);
                                      }
                                    }


                                  </script>



                                  <script>
         // document.getElementById('rent').style.display='none';
         document.getElementById('sell').style.display='none';
         function b()
         {

          var bu = document.getElementById('type').value;
          if(bu=="Sell")
          {
            document.getElementById('sell').style.display='';
            document.getElementById('rent').style.display='none';
          }
          else
          {
            document.getElementById('rent').style.display='';
            document.getElementById('sell').style.display='none';

          }


        }



      
    </script>