 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
 <script type="text/javascript" src="include/dist/script/showToast.js"></script>

 <?php include_once("include/connection.php");
 $uid=$_SESSION['u_id'];    
 $comment=$_POST['comment'];
  $rat=$_POST['rat'];
 $pid=$_POST['pid'];

 


 if($rat!=="" AND  $pid!=="" AND $comment!=="")
 {


        $se=("SELECT * FROM `rating` WHERE u_id=' $uid' AND  property_id='$pid'");  
         $s=mysql_query($se); 
         $row= mysql_num_rows($s);

          if($row==1)
              {


       $up=("UPDATE `rating` SET `rating`='$rat',`message`='$comment' WHERE u_id='$uid' AND  property_id='$pid'"); 
              $u=mysql_query($up); 
                if($u)
                  {
                  ?>
                <script>showToastblack.show('sucessfully submit reviewss...',4000)

            location.href='more_detail_customer_search.php?p=<?php echo $pid;?>';
           
                 </script>
                 <?php
                }
               else
                {
                ?>
                <script>showToastblack.show('no submited..',4000) </script>
               <?php
           }
           
              }
          else
            {


              $up=("INSERT INTO `rating`(`u_id`,`property_id`,`rating`,`message`) VALUES ($uid,$pid,$rat,'$comment')"); 
              $u=mysql_query($up); 
                if($u)
                  {
                  ?>
                <script>showToastblack.show('sucessfully submit reviewss...',4000)

 location.href='more_detail_customer_search.php?p=<?php echo $pid;?>';
                </script>
                 <?php
                }
               else
                {
                ?>
                <script>showToastblack.show('no submited..',4000) </script>
               <?php
           }

  }





}
?>








