 <div class="container">
                <div class="row">
                  <div class="copyrights-col-left col-md-6 col-sm-6">
                    <p>&copy; 2016 RealEstate. All Rights Reserved</p>
                  </div>
                  <div class="copyrights-col-right col-md-6 col-sm-6">
                    <div class="social-icons">
                      <a href="#" ><i class="fa fa-facebook"></i></a>
                      <a href="#"><i class="fa fa-twitter"></i></a>
                      <a href="#" ><i class="fa fa-pinterest"></i></a>
                      <a href="#" ><i class="fa fa-google-plus"></i></a>
                      <a href="#" target="_blank"><i class="fa fa-youtube"></i></a>
                      <a href="#"><i class="fa fa-rss"></i></a>
                    </div>
                  </div>
                </div>
              </div>
              
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/58dfbf43f97dd14875f5b2c3/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->