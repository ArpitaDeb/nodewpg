 <?php include("include/connection.php");?>

<?php
if(!isset($_SESSION['u_id']))
{
header("location:index.php");
}
?>
 <!DOCTYPE HTML>
 <html class="no-js">
 <head>
<!-- Basic Page Needs
  ================================================== -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Real Estate</title>
  <link rel="icon" type="image/png" href="favicon.png">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="format-detection" content="telephone=no">
<!-- CSS
  ================================================== -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
  <!-- Color Style -->
  <link class="alt" href="colors/color1.css" rel="stylesheet" type="text/css">
  <link href="style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
<!-- SCRIPTS
  ================================================== -->
  <script src="js/modernizr.js"></script><!-- Modernizr -->
  
</head>
<body class="home">

  <div class="body">
    <!-- Start Site Header -->
    <!-- Start Site Header -->
    <header class="site-header">

      <?php include("top_header.php");?>
      
      <?Php include("middle_header.php");?>

      <?php include("menu.php");?>
         
    </header>

    <!-- Start Content -->
    <div class="main" role="main">
      <div id="content" class="content full">
        <div class="featured-blocks">
          <div class="">
              <!---maincontant contant                                                             ------->
              <div class="container">

  <!-- Modal -->
  <div role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Change Password</h4>
       </div>
        <div class="modal-body">
		<!-------- login--------------------->
		<div class="container">
<br />
  <form class="form-horizontal" role="form" action="" >
   <div id="message_change_pass"> </div>

  
    <div class="form-group">
      <label class="control-label col-sm-2">Old Password:</label>
      <div class="col-sm-3">          
        <input type="password" class="form-control" id="cold_pass" placeholder="Enter old password">
      </div>
    </div>
   
   <div class="form-group">
      <label class="control-label col-sm-2">New Password:</label>
      <div class="col-sm-3">          
        <input type="password" class="form-control" id="cnew_confirm_pass1" placeholder="Enter New password">
      </div>
    </div>
   <div class="form-group">
      <label class="control-label col-sm-2">New Confirm  Password:</label>
      <div class="col-sm-3">          
        <input type="password" class="form-control" id="cnew_confirm_pass2" placeholder="Enter New Confirm password">
      </div>
    </div>
	
      <div class="form-group">
      <label class="control-label col-sm-2"></span> </label>
      <div class="col-sm-3">          
          <button type="submit" id="change_pass" name="change_pass" class="btn btn-success" style="width: 100%;">Change password</button>
      </div>
    </div>
      
     
  </form>
</div>
		
		<!---------------------------end------------>
         
        </div>
        
      </div>
      
    </div>
  </div>
  
</div>
                <!---end                                                                      contant------->
                
          </div>
        </div>
       


         <div class="padding-tb45 bottom-blocks">
          <div class="container">

          </div>
        </div>

       
       <!-- End Site Footer -->
       <a id="back-to-top"><i class="fa fa-angle-double-up"></i></a>
     </div>
         <footer class="site-footer-bottom">
         <?Php include("footer.php");?>
       </footer>
     <script src="js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call --> 
     <script src="plugins/flexslider/js/jquery.flexslider.js"></script> <!-- FlexSlider --> 
     <script src="js/helper-plugins.js"></script> <!-- Plugins --> 
     <script src="js/bootstrap.js"></script> <!-- UI --> 
     <script src="js/waypoints.js"></script> <!-- Waypoints --> 
     <script src="js/init.js"></script> <!-- All Scripts -->
     <!--[if lte IE 9]><script src="js/script_ie.js"></script><![endif]--> 


   </body>

   </html>
   
<script type="text/javascript">

$(function() {$("#change_pass").click(function() {


var password = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
var cold_pass = $("#cold_pass").val();
var cnew_confirm_pass1 = $("#cnew_confirm_pass1").val();
var cnew_confirm_pass2 = $("#cnew_confirm_pass2").val();


 
 if(cold_pass==''){
  //alert("Enter password");
  showToastblack.show('Enter Old password',2000)
  $("#cold_pass").focus();
}

else if(cnew_confirm_pass1==''){
  //alert("Enter password");
  showToastblack.show('Enter New password',2000)
  $("#cnew_confirm_pass1").focus();
}

else if($("#cnew_confirm_pass1").val().search(password) == -1) {
         // alert("password is not valied at least one number, one lowercase and one uppercase letter at least six characters");
      showToastblack.show('password is not valid at least one number, one lowercase and one uppercase letter at least six characters',4000)
      $("#cnew_confirm_pass1").focus();
 }

else if(cnew_confirm_pass2==''){
  //alert("Enter password");
  showToastblack.show('Enter New Confirm password',2000)
  $("#cnew_confirm_pass2").focus();
}

else if($("#cnew_confirm_pass2").val().search(password) == -1) {
         // alert("password is not valied at least one number, one lowercase and one uppercase letter at least six characters");
      showToastblack.show('password is not valid at least one number, one lowercase and one uppercase letter at least six characters',4000)
      $("#cnew_confirm_pass2").focus();
 }

else if(cnew_confirm_pass1!=cnew_confirm_pass2){
  //alert("Enter password");
  showToastblack.show('new password and New Cinfirm password are not match',2000)
  $("#cnew_confirm_pass1").focus();
}
 
else
{
var dataString = '&cold_pass='+ cold_pass +'&cnew_confirm_pass1='+ cnew_confirm_pass1 +'&cnew_confirm_pass2='+ cnew_confirm_pass2;
$.ajax({
type: "POST",
url: "request_change_pass.php",
data: dataString,
cache: true,
success: function(html)
{
$("#message_change_pass").after(html);
document.getElementById('cold_pass').value='';
document.getElementById('cnew_confirm_pass1').value='';
document.getElementById('cnew_confirm_pass2').value='';
//document.getElementById('lpassword').value='';
//$("#email").focus();
}  
});
}
return false;
});
});

</script>
