 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  
 <?php include_once("include/connection.php");
  $uid=$_SESSION['u_id'];    
 $categoty=$_POST['categoty'];
 $area=$_POST['area'];
  $price=$_POST['price'];
 
 $bedrooms=$_POST['bedrooms'];
  $action=$_POST['action'];

  $address=$_POST['address'];

  $fcity=$_POST['fcity'];
 $mobile=$_POST['mobile'];
   $p_id=$_POST['pid'];
  


  if($categoty!="")
  {
 
                           
    $up=("UPDATE request SET Category_id='$categoty',area='$area',price='$price',Bedrooms='$bedrooms',action='$action',des='$address',city='$fcity',mobile='$mobile' WHERE p_id='$p_id'");	
                           $u=mysql_query($up);	
                           if($u)
                           {
                                ?>
                                 <script>showToastblack.show('sucessfully update...',4000) </script>
                                    <?php
                           }
 else {
      ?>
                                 <script>showToastblack.show('no ooooooooo update...',4000) </script>
                                    <?php
 }
                          
                           
  }
 ?>

  






