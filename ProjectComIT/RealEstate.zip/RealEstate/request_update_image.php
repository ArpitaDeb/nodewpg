 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  
 <?php include_once("include/connection.php");
  $uid=$_SESSION['u_id']; 
  
  $poto_id=$_POST['pid'];
  $p_path=$_POST['path'];
  $url=$_POST['url'];  //property id
  
  
  
 if($poto_id!="")
 
 {
                           //sleep(2);
   // $up=("UPDATE properties SET Category_id='$categoty',area='$area',price='$price',Bedrooms='$bedrooms',floor='$floor',facing='$facing',address='$address',city='$fcity',mobile='$mobile',action='$action' WHERE p_id='$p_id'");	
                     
           
               
                  $sel1=mysql_query("SELECT * FROM `photo` WHERE photo_id = '$poto_id'");
                
                   while($a = mysql_fetch_array($sel1))
			{
                       unlink($a['path']);
                        }
                        $del=mysql_query("DELETE FROM photo WHERE photo_id='$poto_id'");
                    
                        $file_name=$_FILES['profile']['name'];
                        $ex=explode(".",$file_name); 
                        $type=$ex[1];
                        $path="property_image/"."865".time().".".$type;
                        move_uploaded_file($_FILES['profile']['tmp_name'],$path);
               
                        //end_profile_image --------->
                        
                       $up = mysql_query("insert into photo (`p_id`, `path`, `u_id`) values($url,'$path',$uid)");
                 
 
                     
                     if($up)
                     {
                          
                              
                      ?>
                   
                  <script>
                  
 location.href='property_image_info.php?pp=<?php echo $url;?>';
showToastblack.show('sucessfully  propertys.',4000) </script>
                     <?php
                         
                     }
                  

                     
                           
  }
  
  
 $pro_id=$_POST['pid1'];

  
  sleep(1);
  
  if($pro_id!="")
 
 {
                          
   // $up=("UPDATE properties SET Category_id='$categoty',area='$area',price='$price',Bedrooms='$bedrooms',floor='$floor',facing='$facing',address='$address',city='$fcity',mobile='$mobile',action='$action' WHERE p_id='$p_id'");	
                  
           
              
               $pro=mysql_query("SELECT * FROM `properties` WHERE p_id = ' $pro_id'");
                
                   while($a1 = mysql_fetch_array($pro))
			{
                           unlink($a1['pro_image']);
                        }
                        mysql_query("UPDATE properties SET pro_image='' where p_id = '$pro_id'");
                        
                    
                        $file_name=$_FILES['profile1']['name'];
                        $ex=explode(".",$file_name);
                        $type=$ex[1];
                        $path1="property_image/"."865".time().".".$type;
                        move_uploaded_file($_FILES['profile1']['tmp_name'],$path1);
               
                        //end_profile_image --------->
                        
                  
                $up1= mysql_query("UPDATE properties SET pro_image='$path1' where p_id = '$pro_id'");
                     
                     if($up1)
                     {
                          
                              
                      ?>
                   
                  <script>
                  
 location.href='property_image_info.php?pp=<?php echo $pro_id;?>';
showToastblack.show('sucessfully  propertys.',4000) </script>
                     <?php
                         
                     }
                  

                     
                           
  }
  
  
  
  
  
  
  
  
 ?>

  






