<div class="site-showcase">
  <div class="slider-mask overlay-transparent"></div>
  <!-- Start Hero Slider -->
  <div class="hero-slider flexslider clearfix" data-autoplay="yes" data-pagination="no" data-arrows="yes" data-style="fade" data-pause="yes">
    <ul class="slides">
      <li class=" parallax" style="background-image:url(images/slide2.jpg);">
      </li>
      <li class="parallax" style="background-image:url(images/slide1.jpg);">
      </li>
    </ul>
  </div>