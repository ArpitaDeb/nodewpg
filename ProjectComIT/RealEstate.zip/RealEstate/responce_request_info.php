 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  
 <?php include_once("include/connection.php");?>

  

<?php
//show propertyee
$sid=$_POST['s1'];
$stu=$_POST['s2'];

if($_POST['s2']=='1')
{
$a1="update request set status='0' where p_id='$sid'";
$v1=mysql_query($a1);
}
else
{
$a2="update request set status='1' where p_id='$sid'";
$v2=mysql_query($a2);

}


//delete

if($_POST['adel']!="");
{
                 $p_id=$_POST['del'];
                     $del2=mysql_query("DELETE FROM request WHERE p_id = '$p_id'");

                     if($del2)
                     {
                      ?>
                   <script>showToastblack.show('sucessfully delete propertys.',4000) </script>
                     <?php
                         
                     }
   
}
  ?>
  
  <?Php
  
  $u_id=$_SESSION['u_id'];
static $a=0;
               $q = mysql_query("select request.*,cities.city_name,Category_type from request join cities on request.city = cities.city_id join category on request.Category_id = category.Category_id where u_id='$u_id' ORDER BY p_id ASC");
               //$q = mysql_query("SELECT * FROM `properties`");
			while($arr=mysql_fetch_object($q))
			{
                            $a++;
			?>
                  
                  
                <div class="col-sm-4" align="center">  
                    <br> <br>
                     <img src="images/required.png" width="400" height="170" draggable="false"/> 
                    </div>

                 
   <div class="col-sm-8"> 
          <br>
                   <?php echo '<b style="color: #423939;font-size: 11pt;">'."Category: ".'</b>'; ?> <?php echo $arr->Category_type; ?><br>
                     <?php echo '<b style="color: #423939;font-size: 11pt;">'."Price: ".'</b>'; ?> <?php echo $arr->price." - ".$arr->Bedrooms."BHK"; ?><br>
                  <?php echo '<b style="color: #423939;font-size: 11pt;">'."Action: ".'</b>'?> <?php echo $arr->action; ?><br>
                    <?php echo '<b style="color: #423939;font-size: 11pt;">'."Area: ".'</b>'?>  <?php echo $arr->area." Sqft"; ?><br>
               
                  
                    <?php echo '<b style="color: #423939;font-size: 11pt;">'."Description: ".'</b>'?> <?php echo $arr->des; ?><br>
                   <?php echo '<b style="color: #423939;font-size: 11pt;">'."City: ".'</b>'?> <?php echo $arr->city_name; ?><br>
                     <?php echo '<b style="color: #423939;font-size: 11pt;">'."Mobil No: ".'</b>'?> <?php echo $arr->mobile; ?><br>
                       
                 
                        <?Php 
              if($arr->status=="1")
              {
               ?>
            <?php echo '<b style="color: #423939;font-size: 11pt;">'."Status: ".'</b>'?> <b style="color: green;">Show</b><br>
            <?php
               }
	    else
	      {
	     ?>
            <?php echo '<b style="color: #423939;font-size: 11pt;">'."Status: ".'</b>'?><b style="color: red;">Hide</b><br>
          <?Php
             }
             ?>
                       
                       <br>
                 
                      
                       <a href="update_request_info.php?up=<?php echo $arr->p_id;?>" class="btn btn-warning btn-sm"><b class="fa fa-edit w3-large" style="font-size: 11pt;"  ></b>Edit Info </a>
                     
                       
                       <a href="#"  class="btn btn-danger btn-sm" onClick="del(<?php echo  $arr->p_id; ?>);"  > <b class="fa fa-trash w3-large" style="font-size: 11pt;"></b> Delete </a>
                       
                        <?Php 
              if($arr->status=="0")
              {
               ?>
          <a href="#" class="btn btn-success btn-sm"  id="st"  onClick="status(<?php echo  $arr->p_id; ?>,<?php echo  $arr->status; ?>);"></b>Show</a>       
            <?php
               }
	    else
	      {
	     ?>
   <a href="#" class="btn btn-success btn-sm"   id="st"  onClick="status(<?php echo  $arr->p_id; ?>,<?php echo  $arr->status; ?>);"></b>Hide</a>       
          <?Php
             }
             ?>
                       
                       <br> <br><br>
                       
         </div>
                  <hr style="background-color:#999966;">
                        <?Php
                        }
                   ?>
                   <?php    
                   if($a==0)
                   {
                    echo "no add any request";
                   }
                    ?>