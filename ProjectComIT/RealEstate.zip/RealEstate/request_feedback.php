 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  
 <?php include_once("include/connection.php");
 
  $name=$_POST['feed_name'];    
 $email=$_POST['feed_email'];
 $mess=$_POST['feed_mess'];
   

 if($name!="")
 {                    
                        
  $q = mysql_query("insert into feedback(name,email,feedback)"
       . " values('$name','$email','$mess')");
  
              
                        if($q)
                        {
                             
                            ?>
                             <script>showToastblack.show('sucessfully add Feedback.',4000) </script>
                           <?php
                        }
                        else
                        {
                        echo "no";
                        }


     
 }
  
 ?>

  






