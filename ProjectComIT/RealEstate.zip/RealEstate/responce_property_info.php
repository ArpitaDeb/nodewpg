 <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  
 <?php include_once("include/connection.php");?>

  

<?php
//show propertyee
$sid=$_POST['s1'];
$stu=$_POST['s2'];

if($_POST['s2']=='1')
{
$a1="update properties set status='0' where p_id='$sid'";
$v1=mysql_query($a1);
}
else
{
$a2="update properties set status='1' where p_id='$sid'";
$v2=mysql_query($a2);

}


//delete
if($_POST['alldel']!="");
{
                 $p_id=$_POST['alldel'];
                 $sel=mysql_query("SELECT * FROM `properties` WHERE p_id ='$p_id'");
                 $fet=mysql_fetch_array($sel);
                 unlink($fet['pro_image']);
                  $sel1=mysql_query("SELECT * FROM `photo` WHERE p_id = '$p_id'");
                
                   while($a=  mysql_fetch_array($sel1))
			{
                    
                        unlink($a['path']);
                        }
                        
                     $del1=mysql_query("DELETE FROM photo WHERE p_id = '$p_id'");
                     $del2=mysql_query("DELETE FROM properties WHERE p_id = '$p_id'");

                      $del3=mysql_query("DELETE FROM rating WHERE  property_id = '$p_id'");
                     if($del2)
                     {
                      ?>
                   
                  <script>
                  
    alert('sucessfully delete propertys');
showToastblack.show('sucessfully delete propertys.',4000) </script>
                     <?php
                         
                     }
                  

 
    
    
}
  ?>
  
  <?Php
  
  $u_id=$_SESSION['u_id'];
static $a=0;
               $q = mysql_query("select properties.*,cities.city_name,Category_type from properties join cities on properties.city = cities.city_id join category on  properties.Category_id = category.Category_id where u_id='$u_id' ORDER BY p_id ASC");
               //$q = mysql_query("SELECT * FROM `properties`");
			while($arr=mysql_fetch_object($q))
			{
                            $a++;
			?>
                  
                  
                <div class="col-sm-4" align="center">  
                    <br>
                    
                    <?Php 
                    if($arr->pro_image=="")
                    {
                     ?>
                    <img src="images/images.png" width="200" height="100" draggable="false"/> 
                     <?php
                    }
                    else 
                        {?>
                     <img src="<?php echo $arr->pro_image; ?>" width="400" height="170" draggable="false"/> 
     
                    <?php
                        }
                     ?>
                    </div>

                 
   <div class="col-sm-8"> 
          <br>
                   <?php echo '<b style="color: #423939;font-size: 11pt;">'."Category: ".'</b>'; ?> <?php echo $arr->Category_type; ?><br>
                     <?php echo '<b style="color: #423939;font-size: 11pt;">'."Price: ".'</b>'; ?> <?php echo $arr->price." - ".$arr->Bedrooms."BHK"; ?><br>
                 
                    <?php echo '<b style="color: #423939;font-size: 11pt;">'."Area: ".'</b>'?>  <?php echo $arr->area." Sqft"; ?><br>
               
                    <?php echo '<b style="color: #423939;font-size: 11pt;">'."Floor: ".'</b>'?> <?php echo $arr->floor; ?><br>
                    <?php echo '<b style="color: #423939;font-size: 11pt;">'."Facing: ".'</b>'?> <?php echo $arr->facing; ?><br>
                   
                    <?php echo '<b style="color: #423939;font-size: 11pt;">'."Address: ".'</b>'?> <?php echo $arr->address; ?><br>
                   <?php echo '<b style="color: #423939;font-size: 11pt;">'."City: ".'</b>'?> <?php echo $arr->city_name; ?><br>
                     <?php echo '<b style="color: #423939;font-size: 11pt;">'."Mobil No: ".'</b>'?> <?php echo $arr->mobile; ?><br>
                       <?php echo '<b style="color: #423939;font-size: 11pt;">'."Action: ".'</b>'?> <?php echo $arr->action; ?><br>
                 
                        <?Php 
              if($arr->status=="1")
              {
               ?>
            <?php echo '<b style="color: #423939;font-size: 11pt;">'."Status: ".'</b>'?> <b style="color: green;">Show</b><br>
            <?php
               }
	    else
	      {
	     ?>
            <?php echo '<b style="color: #423939;font-size: 11pt;">'."Status: ".'</b>'?><b style="color: red;">Hide</b><br>
          <?Php
             }
             ?>
                       
                       <br>
                 
                      
                       <a href="update_property_info.php?up=<?php echo $arr->p_id;?>" class="btn btn-warning btn-sm"><b class="fa fa-edit w3-large" style="font-size: 11pt;"  ></b>Edit Info </a>
                       <a href="property_image_info.php?pp=<?php echo $arr->p_id;?>" class="btn btn-info btn-sm"><b class="fa fa-edit w3-large" style="font-size: 11pt;"></b>Edit images </a>
                       
                       <a href="#"  class="btn btn-danger btn-sm" onClick="del(<?php echo  $arr->p_id; ?>);"  > <b class="fa fa-trash w3-large" style="font-size: 11pt;"></b> Delete </a>
                       
                        <?Php 
              if($arr->status=="0")
              {
               ?>
          <a href="#" class="btn btn-success btn-sm"  id="st"  onClick="status(<?php echo  $arr->p_id; ?>,<?php echo  $arr->status; ?>);"></b>Show</a>       
            <?php
               }
	    else
	      {
	     ?>
   <a href="#" class="btn btn-success btn-sm"   id="st"  onClick="status(<?php echo  $arr->p_id; ?>,<?php echo  $arr->status; ?>);"></b>Hide</a>       
          <?Php
             }
             ?>
                       
                       <br> <br><br>
                       
         </div>
                  <hr style="background-color:#999966;">
                        <?Php
                        }
                   ?>
                   <?php    
                   if($a==0)
                   {
                    echo "no add propertys";
                   }
                    ?>