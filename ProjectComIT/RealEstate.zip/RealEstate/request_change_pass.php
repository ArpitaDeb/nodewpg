<link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
<script type="text/javascript" src="include/dist/script/showToast.js"></script>

<?php
include_once("include/connection.php");

$ol = $_POST['cold_pass'];
$old = base64_encode($ol);

$p1 = $_POST['cnew_confirm_pass1'];
$pss1 = base64_encode($p1);

$p2 = $_POST['cnew_confirm_pass2'];
$pss2 = base64_encode($p2);

if ($old != "" && $pss1 != "" && $pss2 != "") {
    $e = $_SESSION['u_id'];

    if ($pss1 === $pss2) {

        $u1 = "select password from user where u_id='$e'";
        $ex = mysql_query($u1);
        $re = mysql_fetch_array($ex);

        if ($re['password'] == $old) {
            $u = "update user set password='$pss1' where u_id='$e'";
            $ex1 = mysql_query($u);
            ?>
            <script>showToastblack.show('your password is changed sucessfully.', 2000)</script>
            <?php
        } else {
            ?>
            <script>showToastblack.show('Invalid old password.', 2000)</script>
            <?Php
        }
    } else {
        ?>
        <script>showToastblack.show('password did not match.', 2000)</script>
        <?php
    }
}
?>