 <?php include("include/connection.php");?>


 <!DOCTYPE HTML>
 <html class="no-js">
 <head>
<!-- Basic Page Needs
  ================================================== -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Real Estate</title>
  <link rel="icon" type="image/png" href="favicon.png">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
<!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
  <meta name="format-detection" content="telephone=no">
<!-- CSS
  ================================================== -->
  <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" type="text/css" href="include/dist/style/showToast.css" />
  <script type="text/javascript" src="include/dist/script/showToast.js"></script>
  <!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="css/ie.css" media="screen" /><![endif]-->
  <!-- Color Style -->
  <link class="alt" href="colors/color1.css" rel="stylesheet" type="text/css">
  <link href="style-switcher/css/style-switcher.css" rel="stylesheet" type="text/css">
<!-- SCRIPTS
  ================================================== -->
  <script src="js/modernizr.js"></script><!-- Modernizr -->
  
</head>
<body class="home">

  <div class="body">
    <!-- Start Site Header -->
    <!-- Start Site Header -->
    <header class="site-header">

      <?php include("top_header.php");?>
      
      <?Php include("middle_header.php");?>

      <?php include("menu.php");?>

       <?php include_once("include/signup.php");?>
        <?Php include_once("include/login.php"); ?>
        <?Php include_once("include/forgotpass.php"); ?>
         
    </header>

    <!-- Start Content -->
    <div class="main" role="main">
      <div id="content" class="content full">
        <div class="featured-blocks">
          <div class="">
              <!---maincontant contant                                                             ------->
              <div class="container">

  <!-- Modal -->
  <div role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" align="left">
         
           &ensp;FeeedBack
       </div>
        <div class="modal-body">
		<!-------- login--------------------->
		<div class="container">
<br />

<form class="form-horizontal" role="form" action="" id="uploadForm" method="post">
   <div id="feed_m"> </div>

  
 
     
   <div class="form-group">
      <label class="control-label col-sm-2">Name:</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" id="feed_name" name="feed_name" placeholder="Enter Your Name">
      </div>
    </div>
   
   <div class="form-group">
      <label class="control-label col-sm-2">Email:</label>
      <div class="col-sm-3">          
          <input type="text" class="form-control" id="feed_email" name="feed_email" placeholder="Enter Your Email">
      </div>
    </div>
   
  
  
   
   <div class="form-group">
      <label class="control-label col-sm-2">Feed back Message:</label>
      <div class="col-sm-3">          
      
          <textarea class="form-control" rows="5" id="feed_mess" name="feed_mess"></textarea>
      </div>
    </div>
   
  
	
   
      <div class="form-group">
      <label class="control-label col-sm-2"></span></label>
      <div class="col-sm-3">   
          
          <input type="submit" id="submit" name="submit" class="btn btn-success" style="width: 100%;" value="submit"/>
       
      </div>
    </div>
   
   
      
     
  </form>
</div>
		
		<!---------------------------end------------>
         
        </div>
        
      </div>
      
    </div>
  </div>
  <!---- >
</div>
                <!---end                                                                      contant------->
                
          </div>
        </div>
       


         <div class="padding-tb45 bottom-blocks">
          <div class="container">

          </div>
        </div>

      
       <!-- End Site Footer -->
       <a id="back-to-top"><i class="fa fa-angle-double-up"></i></a>
     </div>
      </div>
            <footer class="site-footer-bottom">
         <?Php include("footer.php");?>
       </footer>
     <script src="js/jquery-2.0.0.min.js"></script> <!-- Jquery Library Call --> 
     <script src="plugins/flexslider/js/jquery.flexslider.js"></script> <!-- FlexSlider --> 
     <script src="js/helper-plugins.js"></script> <!-- Plugins --> 
     <script src="js/bootstrap.js"></script> <!-- UI --> 
     <script src="js/waypoints.js"></script> <!-- Waypoints --> 
     <script src="js/init.js"></script> <!-- All Scripts -->
     <!--[if lte IE 9]><script src="js/script_ie.js"></script><![endif]--> 


   </body>

   </html>
   
   <script type="text/javascript">
$(document).ready(function (e) {
	$("#uploadForm").on('submit',(function(e) {
            var emailRegEx = /^[A-Z0-9._]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
            var feed_name = $("#feed_name").val();
            var feed_email = $("#feed_email").val();
            var feed_mess = $("#feed_mess").val();
           
         
            if(feed_name==''){
               showToastblack.show('Enter your Name.',2000)
                $("#feed_name").focus();
                return false;
            }
            

             else if(feed_email==''){
               showToastblack.show('Enter Email.',2000)
               $("#feed_email").focus();
                return false;
            }
            
            else if($("#feed_email").val().search(emailRegEx) == -1) {
         // alert("Email id is not valied");
                showToastblack.show('Email id is not valied',2000)
                 $("#feed_email").focus();
                  return false;
             }
          
            else if(feed_mess==''){
               showToastblack.show('Enter feed Back.',2000)
                $("#feed_email").focus();
                return false;
            }
            else
            {
                   

		e.preventDefault();
                // document.getElementById("submit").value="Sending.....";
		$.ajax({
                        url: "request_feedback.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
                        cache: false,
			processData:false,
                        success: function(html)
                            {
                            $("#feed_m").after(html);
                            //document.getElementById("submit").value="submit.";
                             document.getElementById('feed_name').value='';
                              document.getElementById('feed_email').value='';
                               document.getElementById('feed_mess').value='';
                              
                            }  

		       
                        });
                        
        }
	}));
});
</script>
<?php include_once("include/validation.php");?>